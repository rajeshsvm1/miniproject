from functools import wraps
from django.http import JsonResponse
from django.shortcuts import redirect
from django.contrib import messages

def admin_required(view_func):
    """Decorator to check if user is in Admin group"""
    @wraps(view_func)
    def _wrapped_view(request, *args, **kwargs):
        if not request.user.groups.filter(name='Admin').exists():
            if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                return JsonResponse({
                    'status': 'error',
                    'message': 'Only administrators can perform this action'
                }, status=403)
            messages.error(request, 'Only administrators can perform this action')
            return redirect('projects:project_list')
        return view_func(request, *args, **kwargs)
    return _wrapped_view
