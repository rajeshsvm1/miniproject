def admin_status(request):
    """Add is_admin variable to all template contexts."""
    is_admin = request.user.is_authenticated and request.user.groups.filter(name='Admin').exists()
    is_developer = request.user.is_authenticated and request.user.groups.filter(name='Developer').exists()
    return {
        'is_admin': is_admin,
        'is_developer': is_developer,
    }
