from django.shortcuts import render, get_object_or_404, redirect
from django.http import JsonResponse
from django.contrib import messages
from django.utils import timezone
from django.db.models import Q, Count, Sum
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_http_methods
from django.contrib.auth.decorators import login_required
from django.contrib.auth import get_user_model
from django.contrib.contenttypes.models import ContentType
from django.urls import reverse
from .export_utils import export_csv_data
from .models import (
    Project, Milestone, Activity, Comment, Priority, 
    Status, ProjectLogEntry, Notification
)
from .forms import ProjectForm, MilestoneForm, ActivityForm
from .decorators import admin_required
from .forms import ProjectForm, MilestoneForm, ActivityForm  # Import from forms.py
from datetime import date, timedelta
from django.contrib.auth.decorators import login_required
from django.contrib.auth import get_user_model
import json
from django.contrib.contenttypes.models import ContentType
import logging
from .assign_api import assign_project_user

logger = logging.getLogger(__name__)

@login_required
def assigned_to_me(request):
    projects = Project.objects.filter(assigned_to=request.user, is_archived=False)
    context = {
        'projects': projects,
        'assigned_to_me': True,
        'archived': False,
        'search_query': '',
    }
    return render(request, 'projects/project_list.html', context)

@require_http_methods(["GET", "POST"])
@login_required
@admin_required
def add_milestone(request, project_id):
    """Add new milestone via modal form"""
    project = get_object_or_404(Project, id=project_id)
    if request.method == 'POST':
        form = MilestoneForm(request.POST)
        if form.is_valid():
            milestone = form.save(commit=False)
            milestone.project = project
            milestone.save()
            
            # Log milestone creation
            milestone.log_action(
                user=request.user,
                action='create',
                description=f'Created new milestone: {milestone.name}'
            )
            
            # Create notification for project owner
            if project.assigned_to:
                Notification.objects.create(
                    user=project.assigned_to,
                    notification_type='milestone',
                    content_type=ContentType.objects.get_for_model(milestone),
                    object_id=milestone.id,
                    message=f"New milestone '{milestone.name}' added to your project '{project.name}'"
                )
            
            if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                return JsonResponse({
                    'status': 'success',
                    'message': 'Milestone created successfully'
                })
            else:
                messages.success(request, 'Milestone created successfully')
                return redirect('projects:milestone_list', project_id=project.id)
        else:
            if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                return JsonResponse({
                    'status': 'error',
                    'errors': form.errors
                })
    else:
        form = MilestoneForm()
    return render(request, 'projects/add_milestone_modal.html', {
        'form': form,
        'project': project
    })
from django.shortcuts import render, get_object_or_404, redirect
from django.http import JsonResponse
from django.contrib import messages
from django.utils import timezone
from django.db.models import Q, Count, Sum
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_http_methods
from .models import Project, Milestone, Activity, Comment, Priority, Status
from .forms import ProjectForm, MilestoneForm, ActivityForm  # Import from forms.py
from datetime import date, timedelta
from django.contrib.auth.decorators import login_required
from django.contrib.auth.decorators import login_required
import json
from django.contrib.contenttypes.models import ContentType



@login_required
def dashboard(request):
    """Dashboard view with comprehensive statistics and project breakdown"""
    is_admin = request.user.groups.filter(name='Admin').exists()
    
    # Get the selected user from query parameters (for admin only)
    selected_user_id = request.GET.get('user')
    selected_user = None
    if is_admin and selected_user_id:
        try:
            selected_user = get_user_model().objects.get(id=selected_user_id)
        except get_user_model().DoesNotExist:
            pass
    
    # Base querysets filtered by user role and selection
    if is_admin:
        if selected_user:
            # Show selected user's projects
            projects_queryset = Project.objects.filter(assigned_to=selected_user)
            activities_queryset = Activity.objects.filter(
                milestone__project__assigned_to=selected_user
            )
        else:
            # Show all projects for admin when no user is selected
            projects_queryset = Project.objects
            activities_queryset = Activity.objects
    else:
        # For developers, only show assigned projects
        projects_queryset = Project.objects.filter(assigned_to=request.user)
        activities_queryset = Activity.objects.filter(
            milestone__project__assigned_to=request.user
        )
    
    # Calculate statistics
    total_projects = projects_queryset.count()
    active_projects = projects_queryset.filter(is_archived=False).count()
    archived_projects = projects_queryset.filter(is_archived=True).count()
    
    # Activity statistics
    if is_admin and not selected_user:
        # For admin without a selected user, show all activities
        total_activities = Activity.objects.count()
        completed_activities = Activity.objects.filter(status=Status.CLOSED).count()
        overdue_activities = Activity.objects.filter(
            due_date__lt=timezone.now().date(),
            status=Status.OPEN
        ).count()
    else:
        # For developers and admin with selected user, show assigned activities
        user_to_filter = selected_user if selected_user else request.user
        
        # Only count activities that are directly assigned to the user
        total_activities = Activity.objects.filter(assigned_to=user_to_filter).count()
        completed_activities = Activity.objects.filter(assigned_to=user_to_filter, status=Status.CLOSED).count()
        overdue_activities = Activity.objects.filter(
            assigned_to=user_to_filter,
            due_date__lt=timezone.now().date(),
            status=Status.OPEN
        ).count()
    
    # Points statistics
    if is_admin and not selected_user:
        # For admin, show all points
        total_points = Activity.objects.aggregate(Sum('points'))['points__sum'] or 0
        completed_points = Activity.objects.filter(status=Status.CLOSED).aggregate(Sum('points'))['points__sum'] or 0
    else:
        # For developers and admin with selected user, only show points from assigned activities
        user_to_filter = selected_user if selected_user else request.user
        total_points = Activity.objects.filter(assigned_to=user_to_filter).aggregate(Sum('points'))['points__sum'] or 0
        completed_points = Activity.objects.filter(
            assigned_to=user_to_filter,
            status=Status.CLOSED
        ).aggregate(Sum('points'))['points__sum'] or 0
    
    # Recent comments
    if is_admin:
        if selected_user:
            # Show comments from selected user's projects
            recent_comments = Comment.objects.filter(
                content_type__model__in=['project', 'milestone', 'activity'],
                object_id__in=list(projects_queryset.values_list('id', flat=True)) + 
                            list(Milestone.objects.filter(project__in=projects_queryset).values_list('id', flat=True)) +
                            list(Activity.objects.filter(milestone__project__in=projects_queryset).values_list('id', flat=True))
            ).select_related('content_type').order_by('-created_at')[:5]
        else:
            # Show all comments for admin
            recent_comments = Comment.objects.select_related('content_type').order_by('-created_at')[:5]
    else:
        # For developers, show comments from their assigned projects, milestones, and activities
        assigned_projects = Project.objects.filter(assigned_to=request.user)
        recent_comments = Comment.objects.filter(
            content_type__model__in=['project', 'milestone', 'activity'],
            object_id__in=list(assigned_projects.values_list('id', flat=True)) + 
                        list(Milestone.objects.filter(project__in=assigned_projects).values_list('id', flat=True)) +
                        list(Activity.objects.filter(milestone__project__in=assigned_projects).values_list('id', flat=True))
        ).select_related('content_type').order_by('-created_at')[:5]
    
    # Project breakdown for time tracking
    project_breakdown = []
    for project in projects_queryset.filter(is_archived=False):
        if project.total_points > 0:
            project_breakdown.append({
                'id': project.id,
                'name': project.name,
                'total': project.total_points,
                'completed': project.completed_points,
                'percentage': round((project.completed_points / project.total_points) * 100) if project.total_points > 0 else 0,
                'estimated_hours': project.total_points // 2
            })
    
    # Get all users for the dropdown (only needed for admin)
    users = []
    if is_admin:
        users = get_user_model().objects.all()

    context = {
        'total_projects': total_projects,
        'active_projects': active_projects,
        'archived_projects': archived_projects,
        'total_activities': total_activities,
        'completed_activities': completed_activities,
        'overdue_activities': overdue_activities,
        'total_points': total_points,
        'completed_points': completed_points,
        'estimated_hours': total_points // 2,
        'completion_rate': round((completed_activities / max(total_activities, 1)) * 100),
        'recent_comments': recent_comments,
        'project_breakdown': project_breakdown,
        'is_admin': is_admin,
        'users': users,
        'selected_user': selected_user
    }
    
    return render(request, 'projects/dashboard.html', context)

@login_required
def project_list(request):
    """List projects (active or archived) with search functionality"""
    archived = request.GET.get('archived', 'false') == 'true'
    projects = Project.objects.filter(is_archived=archived)
    users = get_user_model().objects.all()
    # Search functionality
    search_query = request.GET.get('search', '')
    if search_query:
        projects = projects.filter(name__icontains=search_query)
    
    # Check if user is in Admin group
    is_admin = request.user.groups.filter(name='Admin').exists()
    is_developer = request.user.groups.filter(name='Developer').exists()
    
    context = {
        'projects': projects,
        'archived': archived,
        'search_query': search_query,
        'users': users,
        'is_admin': is_admin,
        'is_developer': is_developer,
    }
    return render(request, 'projects/project_list.html', context)

@login_required
def milestone_list(request, project_id):
    """List milestones for a specific project"""
    project = get_object_or_404(Project, id=project_id)
    milestones = project.milestones.all()
    users = get_user_model().objects.all()
    search_query = request.GET.get('search', '')
    if search_query:
        milestones = milestones.filter(name__icontains=search_query)
    
    # Check if user is in Admin group
    is_admin = request.user.groups.filter(name='Admin').exists()
    is_developer = request.user.groups.filter(name='Developer').exists()
    
    context = {
        'project': project,
        'milestones': milestones,
        'search_query': search_query,
        'users': users,
        'is_admin': is_admin,
        'is_developer': is_developer,
    }
    return render(request, 'projects/milestone_list.html', context)

@login_required
def activity_list(request, project_id, milestone_id):
    """List activities for a specific milestone"""
    project = get_object_or_404(Project, id=project_id)
    milestone = get_object_or_404(Milestone, id=milestone_id, project=project)
    activities = milestone.activities.all()
    
    search_query = request.GET.get('search', '')
    if search_query:
        activities = activities.filter(name__icontains=search_query)
    
    # Check if user is in Admin group
    is_admin = request.user.groups.filter(name='Admin').exists()
    is_developer = request.user.groups.filter(name='Developer').exists()
    
    context = {
        'project': project,
        'milestone': milestone,
        'activities': activities,
        'search_query': search_query,
        'is_admin': is_admin,
        'is_developer': is_developer,
    }
    return render(request, 'projects/activity_list.html', context)

@login_required
def activity_detail(request, project_id, milestone_id, activity_id):
    """Show activity details with comments"""
    project = get_object_or_404(Project, id=project_id)
    milestone = get_object_or_404(Milestone, id=milestone_id, project=project)
    activity = get_object_or_404(Activity, id=activity_id, milestone=milestone)
    users = get_user_model().objects.all()
    
    context = {
        'project': project,
        'milestone': milestone,
        'activity': activity,
        'users': users,
    }
    return render(request, 'projects/activity_detail.html', context)

@login_required
def assign_activity(request, activity_id):
    """Assign activity to a user"""
    if request.method == 'POST':
        activity = get_object_or_404(Activity, id=activity_id)
        
        if activity.milestone.project.is_archived:
            return JsonResponse({'status': 'error', 'message': 'Cannot modify activity in archived project'})
        
        user_id = request.POST.get('user_id')
        if user_id == '0':  # Unassign
            activity.assigned_to = None
            activity.save()
            
            # Log unassignment
            activity.log_action(
                user=request.user,
                action='assign',
                description='Activity was unassigned'
            )
            
            return JsonResponse({'status': 'success', 'message': 'Activity unassigned'})
        
        try:
            user = get_user_model().objects.get(id=user_id)
            activity.assigned_to = user
            activity.save()
            
            # Log assignment
            activity.log_action(
                user=request.user,
                action='assign',
                description=f'Activity assigned to {user.get_full_name() or user.username}'
            )
            
            # Create notification for assigned user
            Notification.objects.create(
                user=user,
                notification_type='assignment',
                content_type=ContentType.objects.get_for_model(activity),
                object_id=activity.id,
                message=f"You have been assigned to activity '{activity.name}'"
            )
            
            return JsonResponse({
                'status': 'success',
                'message': f'Activity assigned to {user.get_full_name() or user.username}'
            })
        except get_user_model().DoesNotExist:
            return JsonResponse({'status': 'error', 'message': 'Invalid user'})
            
    return JsonResponse({'status': 'error', 'message': 'Invalid request method'})

@login_required
def backlog_filter(request):
    """Show all overdue items (backlog)"""
    today = timezone.now().date()
    tomorrow = today + timedelta(days=1)

    # Check if user is admin
    is_admin = request.user.groups.filter(name='Admin').exists()

    # Base query for activities
    activities_query = Activity.objects.filter(
        due_date__lt=timezone.now().date(),
        status=Status.OPEN
    ).select_related('milestone__project')

    # Base query for milestones
    milestones_query = Milestone.objects.filter(
        due_date__lt=timezone.now().date(),
        activities__status=Status.OPEN
    ).distinct().select_related('project')

    # If user is not admin, filter by assigned projects
    if not is_admin:
        activities_query = activities_query.filter(
            Q(milestone__project__assigned_to=request.user) |
            Q(assigned_to=request.user)
        )
        milestones_query = milestones_query.filter(
            project__assigned_to=request.user
        )

    context = {
        'activities': activities_query,
        'milestones': milestones_query,
        'title': 'All Backlog',
        'today': today,
        'tomorrow': tomorrow,
        'is_admin': is_admin,
    }
    return render(request, 'projects/filter_view.html', context)

@login_required
def next_4_weeks_filter(request):
    """Show items due in the next 4 weeks"""
    today = timezone.localtime().date()  # Use localtime() to get the correct timezone
    four_weeks_later = today + timedelta(weeks=4)
    tomorrow = today + timedelta(days=1)
    
    # Check if user is admin
    is_admin = request.user.groups.filter(name='Admin').exists()
    
    # Base query for activities
    activities = Activity.objects.filter(
        due_date__gte=today,
        due_date__lt=four_weeks_later,
        status=Status.OPEN,  # Only open activities
        milestone__status=Status.OPEN,  # Only activities from open milestones
        milestone__project__is_archived=False  # Only from non-archived projects
    ).select_related('milestone__project')
    
    # Base query for milestones
    milestones = Milestone.objects.filter(
        due_date__gte=today,
        due_date__lt=four_weeks_later,
        status=Status.OPEN,  # Only open milestones
        project__is_archived=False  # Only milestones from non-archived projects
    ).select_related('project')
    
    # If user is not admin, filter by assigned projects and activities
    if not is_admin:
        activities = activities.filter(
            Q(milestone__project__assigned_to=request.user) |
            Q(assigned_to=request.user)
        )
        milestones = milestones.filter(
            project__assigned_to=request.user
        )

    # Convert querysets to lists
    activities_list = list(activities)
    milestones_list = list(milestones)

    # Sort function that handles special cases (today and tomorrow)
    tomorrow = today + timedelta(days=1)
    def sort_key(item):
        due_date = item.due_date
        if due_date == today:
            return (0, due_date)  # Today comes first
        elif due_date == tomorrow:
            return (1, due_date)  # Tomorrow comes second
        else:
            return (2, due_date)  # Rest sorted by date
            
    print(f"Debug - Today: {today}, Tomorrow: {tomorrow}")  # Debug line

    # Sort both lists
    activities_list.sort(key=sort_key)
    milestones_list.sort(key=sort_key)

    # Combine activities and milestones and sort them by due date
    class CombinedItem:
        def __init__(self, item, is_milestone):
            self.item = item
            self.is_milestone = is_milestone
            self.due_date = item.due_date
            self.sort_key = sort_key(item)

    # Create combined list of activities and milestones
    combined_items = []
    
    # Only add activities that are not closed
    for activity in activities_list:
        if activity.status != Status.CLOSED:
            combined_items.append(CombinedItem(activity, False))
    
    # Only add milestones that are not closed and not marked as closed via is_closed property
    for milestone in milestones_list:
        if milestone.status != Status.CLOSED and not milestone.is_closed:
            combined_items.append(CombinedItem(milestone, True))
    
    # Sort combined items using the same sorting logic
    combined_items.sort(key=lambda x: x.sort_key)

    context = {
        'combined_items': combined_items,
        'title': 'Next 4 Weeks',
        'today': today,
        'tomorrow': tomorrow,
    }
    return render(request, 'projects/filter_view.html', context)

# Form handling views
from .decorators import admin_required

@require_http_methods(["GET", "POST"])
@login_required
@admin_required
def add_project(request):
    """Add new project via modal form"""
    if request.method == 'POST':
        form = ProjectForm(request.POST)
        if form.is_valid():
            project = form.save()
            
            # Log the create action
            project.log_action(
                user=request.user,
                action='create',
                description=f'Created new project: {project.name}'
            )
            
            if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                return JsonResponse({
                    'status': 'success',
                    'message': 'Project created successfully',
                    'project_id': project.id,
                    'project_name': project.name
                })
            else:
                messages.success(request, 'Project created successfully')
                return redirect('projects:project_list')
        else:
            if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                return JsonResponse({
                    'status': 'error',
                    'errors': form.errors
                })
    else:
        form = ProjectForm()
    
    return render(request, 'projects/add_project_modal.html', {'form': form})


@login_required
@require_http_methods(["GET", "POST"])
def add_activity(request, project_id, milestone_id):
    """Add new activity with points via modal form"""
    project = get_object_or_404(Project, id=project_id)
    milestone = get_object_or_404(Milestone, id=milestone_id, project=project)
    
    if request.method == 'POST':
        form = ActivityForm(request.POST)
        if form.is_valid():
            activity = form.save(commit=False)
            activity.milestone = milestone
            activity.save()
            
            # Log activity creation
            activity.log_action(
                user=request.user,
                action='create',
                description=f'Created new activity: {activity.name} in milestone: {milestone.name}'
            )
            
            # Create notifications for project owner and assigned user
            content_type = ContentType.objects.get_for_model(activity)
            
            # Notify project owner
            if milestone.project.assigned_to:
                Notification.objects.create(
                    user=milestone.project.assigned_to,
                    notification_type='activity',
                    content_type=content_type,
                    object_id=activity.id,
                    message=f"New activity '{activity.name}' added to milestone '{milestone.name}'"
                )
            
            # Notify assigned user if different from project owner
            if activity.assigned_to and activity.assigned_to != milestone.project.assigned_to:
                Notification.objects.create(
                    user=activity.assigned_to,
                    notification_type='assignment',
                    content_type=content_type,
                    object_id=activity.id,
                    message=f"You have been assigned to activity '{activity.name}'"
                )
            
            if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                return JsonResponse({
                    'status': 'success',
                    'message': 'Activity created successfully'
                })
            else:
                messages.success(request, 'Activity created successfully')
                return redirect('projects:activity_list', project_id=project.id, milestone_id=milestone.id)
        else:
            if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                return JsonResponse({
                    'status': 'error',
                    'errors': form.errors
                })
    else:
        form = ActivityForm()
    
    return render(request, 'projects/add_activity_modal.html', {
        'form': form,
        'project': project,
        'milestone': milestone
    })

# AJAX Views for dynamic updates
@login_required
def toggle_activity_status(request, activity_id):
    """Toggle activity status between open and closed"""
    if request.method == 'POST':
        activity = get_object_or_404(Activity, id=activity_id)
        if activity.milestone.project.is_archived:
            return JsonResponse({'status': 'error', 'message': 'Cannot modify activity in archived project'})
        new_status = Status.CLOSED if activity.status == Status.OPEN else Status.OPEN
        old_status = activity.status
        activity.status = new_status
        activity.save()
        
        # Log the status change
        activity.log_action(
            user=request.user,
            action='status',
            description=f'Changed status from {old_status} to {new_status}'
        )
        
        messages.success(request, f'Activity {"completed" if activity.status == Status.CLOSED else "reopened"}')
        return JsonResponse({
            'status': 'success', 
            'new_status': activity.status,
            'message': f'Activity {"completed" if activity.status == Status.CLOSED else "reopened"}'
        })
    
    return JsonResponse({'status': 'error'})

@login_required
def update_priority(request, model_type, object_id):
    """Update priority for project, milestone, or activity"""
    if request.method == 'POST':
        priority = request.POST.get('priority')
        
        if model_type == 'project':
            obj = get_object_or_404(Project, id=object_id)
            if obj.is_archived:
                return JsonResponse({'status': 'error', 'message': 'Cannot modify archived project'})
        elif model_type == 'milestone':
            obj = get_object_or_404(Milestone, id=object_id)
            if obj.project.is_archived:
                return JsonResponse({'status': 'error', 'message': 'Cannot modify milestone in archived project'})
        elif model_type == 'activity':
            obj = get_object_or_404(Activity, id=object_id)
            if obj.milestone.project.is_archived:
                return JsonResponse({'status': 'error', 'message': 'Cannot modify activity in archived project'})
        else:
            return JsonResponse({'status': 'error', 'message': 'Invalid model type'})
        
        old_priority = obj.priority
        obj.priority = priority
        obj.save()
        
        priority_labels = {
            'high': 'High Priority',
            'medium': 'Medium Priority',
            'low': 'Low Priority'
        }
        
        # Log priority change
        obj.log_action(
            user=request.user,
            action='priority',
            description=f'Changed priority from {priority_labels.get(old_priority, old_priority)} to {priority_labels.get(priority, priority)}'
        )
        
        messages.success(request, f'Priority changed from {priority_labels.get(old_priority, old_priority)} to {priority_labels.get(priority, priority)}')
        return JsonResponse({
            'status': 'success',
            'message': f'Priority updated to {priority_labels.get(priority, priority)}'
        })
    
    return JsonResponse({'status': 'error'})

@login_required
def update_points(request, activity_id):
    """Update points for an activity (1 point = 30 minutes)"""
    import logging
    logger = logging.getLogger(__name__)
    if request.method == 'POST':
        try:
            activity = get_object_or_404(Activity, id=activity_id)
            if activity.milestone.project.is_archived:
                return JsonResponse({'status': 'error', 'message': 'Cannot modify activity in archived project'})
            points_raw = request.POST.get('points', 0)
            try:
                points = int(points_raw)
            except Exception as e:
                logger.error(f"Invalid points value: {points_raw} ({e})")
                return JsonResponse({'status': 'error', 'message': 'Invalid points value.'}, status=400)
            old_points = activity.points
            activity.points = points
            activity.save()
            
            if points == 0:
                msg = 'Points removed from activity'
            else:
                msg = f'Points updated from {old_points} to {points}'
                
            # Log points change
            activity.log_action(
                user=request.user,
                action='points',
                description=msg
            )
            logger.info(f"Activity {activity_id}: {msg}")
            return JsonResponse({
                'status': 'success',
                'message': f'Points updated to {points}' if points > 0 else 'Points removed'
            })
        except Exception as e:
            logger.error(f"Error updating points for activity {activity_id}: {e}")
            return JsonResponse({'status': 'error', 'message': f'Error updating points: {e}'}, status=500)
    return JsonResponse({'status': 'error', 'message': 'Invalid request method.'}, status=405)

@login_required
@admin_required
def archive_project(request, project_id):
    """Archive a completed project"""
    if request.method == 'POST':
        project = get_object_or_404(Project, id=project_id)
        project.is_archived = True
        project.save()
        
        # Log archive action
        project.log_action(
            user=request.user,
            action='archive',
            description=f'Project "{project.name}" was archived'
        )
        
        messages.success(request, f'Project "{project.name}" archived successfully')
        return JsonResponse({
            'status': 'success',
            'message': 'Project archived successfully'
        })
    
    return JsonResponse({'status': 'error'})

@login_required
@admin_required
def restore_project(request, project_id):
    """Restore an archived project"""
    if request.method == 'POST':
        project = get_object_or_404(Project, id=project_id, is_archived=True)
        project.is_archived = False
        project.save()
        
        messages.success(request, f'Project "{project.name}" restored successfully')
        return JsonResponse({
            'status': 'success',
            'message': 'Project restored successfully'
        })
    
    return JsonResponse({'status': 'error'})



@login_required
@admin_required
def export_data(request):
    """Export all project data as JSON"""
    from django.http import HttpResponse
    import json
    from django.core import serializers
    
    # Serialize all related data
    projects = list(Project.objects.values())
    milestones = list(Milestone.objects.values())
    activities = list(Activity.objects.values())
    comments = list(Comment.objects.values())
    
    export_data = {
        'projects': projects,
        'milestones': milestones,
        'activities': activities,
        'comments': comments,
        'export_date': timezone.now().isoformat(),
        'version': '1.0'
    }
    
    response = HttpResponse(
        json.dumps(export_data, indent=2, default=str),
        content_type='application/json'
    )
    response['Content-Disposition'] = f'attachment; filename="projects-{timezone.now().date()}.json"'
    
    return response

@login_required
@admin_required
def export_csv(request):
    """Export project data as CSV files in a zip archive"""
    return export_csv_data(request)

def get_dashboard_stats(request):
    """API endpoint for dashboard statistics (AJAX)"""
    total_projects = Project.objects.count()
    active_projects = Project.objects.filter(is_archived=False).count()
    total_activities = Activity.objects.count()
    completed_activities = Activity.objects.filter(status=Status.CLOSED).count()
    overdue_activities = Activity.objects.filter(
        due_date__lt=timezone.now().date(),
        status=Status.OPEN
    ).count()
    
    total_points = Activity.objects.aggregate(Sum('points'))['points__sum'] or 0
    completed_points = Activity.objects.filter(status=Status.CLOSED).aggregate(Sum('points'))['points__sum'] or 0
    
    return JsonResponse({
        'total_projects': total_projects,
        'active_projects': active_projects,
        'total_activities': total_activities,
        'completed_activities': completed_activities,
        'overdue_activities': overdue_activities,
        'total_points': total_points,
        'completed_points': completed_points,
        'estimated_hours': total_points // 2,
        'completion_rate': round((completed_activities / max(total_activities, 1)) * 100),
    })

@login_required
def project_logs(request, project_id):
    """Display logs for a specific project"""
    project = get_object_or_404(Project, id=project_id)
    logs = ProjectLogEntry.objects.filter(project=project)
    
    context = {
        'project': project,
        'logs': logs,
    }
    return render(request, 'projects/project_logs.html', context)

@login_required
def get_notifications(request):
    """Get user notifications via AJAX"""
    notifications = Notification.objects.filter(
        user=request.user,
        is_read=False
    ).order_by('-created_at')[:5]
    
    notification_data = []
    for notification in notifications:
        try:
            url = get_object_url(notification.content_object)
            if not url:
                url = '/'
            notification_data.append({
                'id': notification.id,
                'type': notification.notification_type.title(),
                'message': notification.message,
                'created_at': notification.created_at.strftime("%b %d, %Y %I:%M %p"),
                'url': request.build_absolute_uri(url)
            })
        except Exception as e:
            print(f"Error processing notification {notification.id}: {e}")
            continue
    
    return JsonResponse({
        'notifications': notification_data,
        'count': len(notification_data)  # Only count notifications we could process
    })

@login_required
def mark_notification_read(request, notification_id=None):
    """Mark notification(s) as read"""
    if notification_id:
        # Mark specific notification as read
        Notification.objects.filter(
            id=notification_id,
            user=request.user
        ).update(is_read=True)
    else:
        # Mark all notifications as read
        Notification.objects.filter(
            user=request.user
        ).update(is_read=True)
    
    return JsonResponse({'status': 'success'})

def get_object_url(obj):
    """Helper function to get URL for different object types"""
    if isinstance(obj, Project):
        return reverse('projects:project_list')
    elif isinstance(obj, Milestone):
        return reverse('projects:milestone_list', args=[obj.project.id])
    elif isinstance(obj, Activity):
        return reverse('projects:activity_detail', 
                      args=[obj.milestone.project.id, obj.milestone.id, obj.id])
    return '/'
@require_http_methods(["GET", "POST"])
def add_project(request):
    """Add new project via modal form"""
    if request.method == 'POST':
        form = ProjectForm(request.POST)
        if form.is_valid():
            try:
                project = form.save()  # This actually saves to database
                
                # Create notification for assigned developer
                if project.assigned_to:
                    Notification.objects.create(
                        user=project.assigned_to,
                        notification_type='assignment',
                        content_type=ContentType.objects.get_for_model(project),
                        object_id=project.id,
                        message=f"You have been assigned to project '{project.name}'"
                    )
                
                if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                    return JsonResponse({
                        'status': 'success',
                        'message': 'Project created successfully',
                        'project_id': project.id,
                        'project_name': project.name
                    })
                else:
                    messages.success(request, 'Project created successfully')
                    return redirect('projects:project_list')
            except Exception as e:
                if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                    return JsonResponse({
                        'status': 'error',
                        'message': f'Error saving project: {str(e)}'
                    })
        else:
            if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                return JsonResponse({
                    'status': 'error',
                    'errors': form.errors
                })
    else:
        form = ProjectForm()
    
    return render(request, 'projects/add_project_modal.html', {'form': form})


@login_required
def add_comment(request, model_type, object_id):
    """Add comment to project, milestone, or activity"""
    if request.method == 'POST':
        comment_text = request.POST.get('comment', '').strip()
        
        if not comment_text:
            return JsonResponse({'status': 'error', 'message': 'Comment cannot be empty'})
        
        if model_type == 'project':
            obj = get_object_or_404(Project, id=object_id)
            if obj.is_archived:
                return JsonResponse({'status': 'error', 'message': 'Cannot add comments to archived project'})
        elif model_type == 'milestone':
            obj = get_object_or_404(Milestone, id=object_id)
            if obj.project.is_archived:
                return JsonResponse({'status': 'error', 'message': 'Cannot add comments to milestone in archived project'})
        elif model_type == 'activity':
            obj = get_object_or_404(Activity, id=object_id)
            if obj.milestone.project.is_archived:
                return JsonResponse({'status': 'error', 'message': 'Cannot add comments to activity in archived project'})
        else:
            return JsonResponse({'status': 'error', 'message': 'Invalid model type'})
        
        # Create comment using generic foreign key
        content_type = ContentType.objects.get_for_model(obj)
        
        comment = Comment.objects.create(
            content_type=content_type,
            object_id=obj.id,
            text=comment_text,
            user=request.user  # Make sure to save the user
        )
        
        # Create notification for project/milestone/activity owner
        if model_type == 'project' and obj.assigned_to:
            Notification.objects.create(
                user=obj.assigned_to,
                notification_type='comment',
                content_type=content_type,
                object_id=obj.id,
                message=f"New comment on project '{obj.name}'"
            )
        elif model_type == 'milestone' and obj.project.assigned_to:
            Notification.objects.create(
                user=obj.project.assigned_to,
                notification_type='comment',
                content_type=content_type,
                object_id=obj.id,
                message=f"New comment on milestone '{obj.name}'"
            )
        elif model_type == 'activity' and obj.assigned_to:
            Notification.objects.create(
                user=obj.assigned_to,
                notification_type='comment',
                content_type=content_type,
                object_id=obj.id,
                message=f"New comment on activity '{obj.name}'"
            )
        
        # Log comment addition
        obj.log_action(
            user=request.user,
            action='comment',
            description=f'Added comment: {comment_text[:100]}{"..." if len(comment_text) > 100 else ""}'
        )
        
        # Return the comment HTML with user info
        display_name = comment.user.get_full_name() if comment.user else "Anonymous"
        
        messages.success(request, 'Comment added successfully')
        return JsonResponse({
            'status': 'success',
            'message': 'Comment added successfully',
            'comment_html': f'''
                <div class="comment-entry">
                    <div class="comment-header" style="display: flex; align-items: center; gap: 0.5rem; margin-bottom: 0.5rem;">
                        <span class="comment-author" style="font-weight: 500; color: var(--accent);">
                            {display_name}
                        </span>
                        <span style="color: var(--muted); font-size: 0.8rem;">•</span>
                        <span class="comment-date" style="color: var(--muted); font-size: 0.8rem;">
                            {comment.created_at.strftime("%b %d, %Y %I:%M %p")}
                        </span>
                    </div>
                    <div class="comment-text">{comment.text}</div>
                </div>
            '''
        })
    
    return JsonResponse({'status': 'error', 'message': 'Invalid request method'})

def milestone_list(request, project_id):
    """List milestones for a specific project"""
    project = get_object_or_404(Project, id=project_id)
    milestones = project.milestones.all()
    users = get_user_model().objects.all()
    search_query = request.GET.get('search', '')
    if search_query:
        milestones = milestones.filter(name__icontains=search_query)
    
    context = {
        'project': project,
        'milestones': milestones,
        'search_query': search_query,
        'users': users,
    }
    return render(request, 'projects/milestone_list.html', context)


# class ProjectForm(forms.ModelForm):
#     class Meta:
#         model = Project
#         fields = ['name', 'priority', 'due_date']
#         widgets = {
#             'name': forms.TextInput(attrs={
#                 'placeholder': 'Enter project name',
#                 'class': 'form-control',
#                 'required': True,
#                 'maxlength': '100'
#             }),
#             'priority': forms.Select(attrs={'class': 'form-control'}),
#             'due_date': forms.DateInput(attrs={
#                 'type': 'date',
#                 'class': 'form-control',
#                 'required': True
#             }),
#         }

#     def __init__(self, *args, **kwargs):
#         super().__init__(*args, **kwargs)
#         from django.utils import timezone
#         self.fields['due_date'].widget.attrs['min'] = timezone.now().date().strftime('%Y-%m-%d')

# class MilestoneForm(forms.ModelForm):
#     class Meta:
#         model = Milestone
#         fields = ['name', 'priority', 'due_date']
#         widgets = {
#             'name': forms.TextInput(attrs={
#                 'placeholder': 'Enter milestone name',
#                 'class': 'form-control',
#                 'required': True,
#                 'maxlength': '100'
#             }),
#             'priority': forms.Select(attrs={'class': 'form-control'}),
#             'due_date': forms.DateInput(attrs={
#                 'type': 'date',
#                 'class': 'form-control',
#                 'required': True
#             }),
#         }

#     def __init__(self, *args, **kwargs):
#         super().__init__(*args, **kwargs)
#         from django.utils import timezone
#         self.fields['due_date'].widget.attrs['min'] = timezone.now().date().strftime('%Y-%m-%d')

# class ActivityForm(forms.ModelForm):
#     class Meta:
#         model = Activity
#         fields = ['name', 'priority', 'due_date', 'points'
#         widgets = {
#             'name': forms.TextInput(attrs={
#                 'placeholder': 'Enter activity name',
#                 'class': 'form-control',
#                 'required': True,
#                 'maxlength': '100'
#             }),
#             'priority': forms.Select(attrs={'class': 'form-control'}),
#             'due_date': forms.DateInput(attrs={
#                 'type': 'date',
#                 'class': 'form-control',
#                 'required': True
#             }),
#             'points': forms.NumberInput(attrs={
#                 'class': 'form-control',
#                 'min': '0',
#                 'max': '100',
#                 'placeholder': 'e.g., 4 points = 2 hours'
#             }),
#         }

#     def __init__(self, *args, **kwargs):
#         super().__init__(*args, **kwargs)
#         from django.utils import timezone
#         self.fields['due_date'].widget.attrs['min'] = timezone.now().date().strftime('%Y-%m-%d')