from django.core.management.base import BaseCommand
from django.contrib.auth.models import Group, User

class Command(BaseCommand):
    help = 'Create test users'

    def handle(self, *args, **options):
        # Create developer user
        try:
            dev_user = User.objects.get(username='developer')
        except User.DoesNotExist:
            dev_user = User.objects.create_user(
                username='developer',
                email='developer@example.com',
                password='dev123',
                first_name='Developer',
                last_name='User'
            )

        # Add users to their respective groups
        admin_group = Group.objects.get(name='Admin')
        developer_group = Group.objects.get(name='Developer')

        dev_user.groups.clear()
        dev_user.groups.add(developer_group)

        self.stdout.write(self.style.SUCCESS('Successfully created test users'))
