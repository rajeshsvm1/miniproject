from django.core.management.base import BaseCommand
from django.contrib.auth import get_user_model
from django.contrib.auth.models import Group

class Command(BaseCommand):
    help = 'Creates initial admin and developer users and groups'

    def handle(self, *args, **kwargs):
        User = get_user_model()
        
        # Create Admin group
        admin_group, created = Group.objects.get_or_create(name='Admin')
        if created:
            self.stdout.write(self.style.SUCCESS('Successfully created Admin group'))
        
        # Create Developer group
        dev_group, created = Group.objects.get_or_create(name='Developer')
        if created:
            self.stdout.write(self.style.SUCCESS('Successfully created Developer group'))
        
        # Create admin user
        if not User.objects.filter(username='admin').exists():
            admin_user = User.objects.create_superuser(
                username='admin',
                email='admin@example.com',
                password='admin123'
            )
            admin_user.groups.add(admin_group)
            self.stdout.write(self.style.SUCCESS('Successfully created admin user'))
        
        # Create sample developer user
        if not User.objects.filter(username='developer').exists():
            dev_user = User.objects.create_user(
                username='developer',
                email='developer@example.com',
                password='dev123'
            )
            dev_user.groups.add(dev_group)
            self.stdout.write(self.style.SUCCESS('Successfully created developer user'))
