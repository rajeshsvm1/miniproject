// Global functions for use in HTML onclick handlers
window.toggleNotificationPanel = function() {
    const content = document.getElementById('notificationsContent');
    if (content) {
        content.style.display = content.style.display === 'none' ? 'block' : 'none';
    }
};

// Make mark all as read function globally available
window.markAllAsRead = async function() {
    try {
        await fetch('/projects/api/notifications/mark-read/', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRFToken': getCsrfToken()
            }
        });
        const content = document.getElementById('notificationsContent');
        const count = document.getElementById('notificationCount');
        const list = document.getElementById('notificationsList');
        
        if (content) content.style.display = 'none';
        if (count) count.style.display = 'none';
        if (list) list.innerHTML = '<div class="notification-item">No new notifications</div>';
    } catch (error) {
        console.error('Error marking notifications as read:', error);
    }
};

// Notification handling
function initializeNotifications() {
    const bell = document.getElementById('notificationBell');
    const content = document.getElementById('notificationsContent');
    const count = document.getElementById('notificationCount');
    const list = document.getElementById('notificationsList');
    const markAllRead = document.getElementById('markAllRead');

    if (!bell || !content || !count || !list || !markAllRead) {
        console.log('Notification elements not found');
        return; // Not a developer view or elements not found
    }

    // Handle bell click
    bell.addEventListener('click', (e) => {
        e.preventDefault();
        toggleNotificationPanel();
    });

    // Close notifications when clicking outside
    document.addEventListener('click', (e) => {
        if (!bell.contains(e.target) && !content.contains(e.target)) {
            content.style.display = 'none';
        }
    });

    // Mark all as read
    markAllRead.addEventListener('click', async (e) => {
        e.preventDefault();
        try {
            await fetch('/notifications/mark-read/', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRFToken': getCsrfToken()
                }
            });
            content.style.display = 'none';
            count.style.display = 'none';
            list.innerHTML = `
                <div class="notification-empty-state">
                    <i class="fas fa-bell-slash"></i>
                    <p>No new notifications</p>
                </div>
            `;
        } catch (error) {
            console.error('Error marking notifications as read:', error);
        }
    });

    // Initial load and periodic refresh
    loadNotifications();
    setInterval(loadNotifications, 30000); // Check every 30 seconds
}

async function loadNotifications() {
    try {
        console.log('Fetching notifications...');
        const response = await fetch('/projects/api/notifications/');
        const data = await response.json();
        console.log('Notifications data:', data);
        
        const count = document.getElementById('notificationCount');
        const list = document.getElementById('notificationsList');
        
        if (!count || !list) {
            console.log('Notification elements not found:', { count, list });
            return;
        }

        if (data.count > 0) {
            console.log(`Displaying ${data.count} notifications`);
            count.textContent = data.count;
            count.style.display = 'block';
            
            list.innerHTML = data.notifications.map(notification => `
                <div class="notification-item" onclick="handleNotificationClick('${notification.url}', ${notification.id})">
                    <div class="notification-title">${notification.type}</div>
                    <div class="notification-message">${notification.message}</div>
                    <div class="notification-time">${notification.created_at}</div>
                </div>
            `).join('');
        } else {
            console.log('No notifications to display');
            count.style.display = 'none';
            list.innerHTML = `
                <div class="notification-empty-state">
                    <i class="fas fa-bell-slash"></i>
                    <p>No new notifications</p>
                </div>
            `;
        }
    } catch (error) {
        console.error('Error loading notifications:', error);
        console.error('Error details:', error.stack);
    }
}

window.handleNotificationClick = async function(url, notificationId) {
    try {
        await fetch(`/projects/api/notifications/${notificationId}/mark-read/`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRFToken': getCsrfToken()
            }
        });
        window.location.href = url;
    } catch (error) {
        console.error('Error marking notification as read:', error);
        window.location.href = url;
    }
};

function getCsrfToken() {
    const csrfInput = document.querySelector('[name=csrfmiddlewaretoken]');
    return csrfInput ? csrfInput.value : '';
}

// Initialize when the DOM is loaded
document.addEventListener('DOMContentLoaded', initializeNotifications);
