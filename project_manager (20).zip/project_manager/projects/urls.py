from django.urls import path
from . import views


app_name = 'projects'

urlpatterns = [
    # API endpoints
    path('api/project/<int:project_id>/assign-user/', views.assign_project_user, name='assign_project_user'),
    # Main navigation views
    path('', views.dashboard, name='dashboard'),
    path('assigned-to-me/', views.assigned_to_me, name='assigned_to_me'),
    path('projects/', views.project_list, name='project_list'),
    path('projects/<int:project_id>/milestones/', views.milestone_list, name='milestone_list'),
    path('projects/<int:project_id>/milestones/<int:milestone_id>/activities/', views.activity_list, name='activity_list'),
    path('projects/<int:project_id>/milestones/<int:milestone_id>/activities/<int:activity_id>/', views.activity_detail, name='activity_detail'),
    
    # Filter views
    path('backlog/', views.backlog_filter, name='backlog_filter'),
    path('next-4-weeks/', views.next_4_weeks_filter, name='next_4_weeks_filter'),
    
    # Add/Edit forms (Modal endpoints)
    path('add-project/', views.add_project, name='add_project'),
    path('projects/<int:project_id>/add-milestone/', views.add_milestone, name='add_milestone'),
    path('projects/<int:project_id>/milestones/<int:milestone_id>/add-activity/', views.add_activity, name='add_activity'),
    
    # AJAX endpoints for dynamic updates
    path('api/activity/<int:activity_id>/toggle-status/', views.toggle_activity_status, name='toggle_activity_status'),
    path('api/<str:model_type>/<int:object_id>/update-priority/', views.update_priority, name='update_priority'),
    path('api/activity/<int:activity_id>/update-points/', views.update_points, name='update_points'),

    # Milestone comment endpoint for AJAX (to match JS fetch URL)
    path('api/milestone/<int:object_id>/add-comment/', views.add_comment, {'model_type': 'milestone'}, name='add_milestone_comment'),
    
    # Project management actions
    path('api/project/<int:project_id>/archive/', views.archive_project, name='archive_project'),
    path('api/project/<int:project_id>/restore/', views.restore_project, name='restore_project'),
    path('api/activity/<int:activity_id>/assign/', views.assign_activity, name='assign_activity'),
    
    # Comment system
    path('api/<str:model_type>/<int:object_id>/add-comment/', views.add_comment, name='add_comment'),
    
    # Data export/import
    path('export/', views.export_data, name='export_data'),
    path('export-csv/', views.export_csv, name='export_csv'),
    path('api/stats/', views.get_dashboard_stats, name='get_dashboard_stats'),
    
    # Logs
    path('projects/<int:project_id>/logs/', views.project_logs, name='project_logs'),
    
    # Notifications
    path('api/notifications/', views.get_notifications, name='get_notifications'),
    path('api/notifications/mark-read/', views.mark_notification_read, name='mark_all_notifications_read'),
    path('api/notifications/<int:notification_id>/mark-read/', views.mark_notification_read, name='mark_notification_read'),
]
