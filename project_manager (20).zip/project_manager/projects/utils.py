def create_notification(user, notification_type, obj, message):
    """Helper function to create notifications for users"""
    from .models import Notification
    
    # Create notification for the specified user
    return Notification.objects.create(
        user=user,
        notification_type=notification_type,
        content_type=obj.content_type,
        object_id=obj.id,
        message=message
    )
