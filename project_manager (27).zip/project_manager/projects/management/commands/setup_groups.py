from django.core.management.base import BaseCommand
from django.contrib.auth.models import Group, Permission
from django.contrib.auth import get_user_model
from projects.models import Project, Milestone, Activity

class Command(BaseCommand):
    help = 'Create default user groups'

    def handle(self, *args, **options):
        # Create admin group
        admin_group, admin_created = Group.objects.get_or_create(name='Admin')

        # Create developer group
        developer_group, dev_created = Group.objects.get_or_create(name='Developer')

        self.stdout.write(self.style.SUCCESS('Successfully created groups'))
