from django import template
from django.utils import timezone
from datetime import datetime, date

register = template.Library()

@register.filter
def sum_points(activities):
    """
    Returns the sum of points for all activities.
    Usage: {{ activities|sum_points }}
    """
    total = 0
    for activity in activities:
        if activity.points:
            total += activity.points
    return total

@register.filter
def days_until(value):
    """
    Returns the number of days until the given date.
    Usage: {{ value|days_until }}
    """
    if isinstance(value, (datetime, date)):
        today = timezone.localdate()
        delta = value - today
        if delta.days == 0:
            return "Today"
        elif delta.days == 1:
            return "Tomorrow"
        elif delta.days > 1:
            return f"{delta.days} days left"
        else:
            return "Overdue"
    return ""

@register.filter
def divide(value, arg):
    """
    Divides the value by the argument.
    Usage: {{ value|divide:2 }}
    """
    try:
        return float(value) / float(arg)
    except (ValueError, ZeroDivisionError, TypeError):
        return 0

@register.filter
def multiply(value, arg):
    """
    Multiplies the value by the argument.
    Usage: {{ value|multiply:2 }}
    """
    try:
        return float(value) * float(arg)
    except (ValueError, TypeError):
        return 0
