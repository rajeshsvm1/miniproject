from django.shortcuts import render, get_object_or_404
from django.contrib.auth.decorators import login_required
from .models import Project, ProjectLogEntry

@login_required
def project_logs(request, project_id):
    """Display logs for a specific project"""
    project = get_object_or_404(Project, id=project_id)
    logs = ProjectLogEntry.objects.filter(project=project)
    
    context = {
        'project': project,
        'logs': logs,
    }
    return render(request, 'projects/project_logs.html', context)
