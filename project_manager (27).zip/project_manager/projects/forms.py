from django import forms
from .models import Project, Milestone, Activity

class ProjectForm(forms.ModelForm):
    assigned_to = forms.ModelChoiceField(
        queryset=None,
        required=False,
        widget=forms.Select(attrs={'class': 'form-control'}),
        label='Assign to User'
    )

    class Meta:
        model = Project
        fields = ['name', 'priority', 'due_date', 'assigned_to']
        widgets = {
            'name': forms.TextInput(attrs={
                'placeholder': 'Enter project name',
                'class': 'form-control',
                'required': True,
                'maxlength': '100'
            }),
            'priority': forms.Select(attrs={'class': 'form-control'}),
            'due_date': forms.DateInput(attrs={
                'type': 'date',
                'class': 'form-control',
                'required': True
            }),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        from django.contrib.auth import get_user_model
        from django.utils import timezone
        self.fields['due_date'].widget.attrs['min'] = timezone.now().date().strftime('%Y-%m-%d')
        self.fields['assigned_to'].queryset = get_user_model().objects.all()

class MilestoneForm(forms.ModelForm):
    template = forms.ModelChoiceField(
        queryset=None,
        required=False,
        empty_label="None (Empty milestone)",
        widget=forms.Select(attrs={'class': 'form-control'})
    )
    
    class Meta:
        model = Milestone
        fields = ['name', 'priority', 'due_date']
        widgets = {
            'name': forms.TextInput(attrs={
                'placeholder': 'Enter milestone name',
                'class': 'form-control',
                'required': True,
                'maxlength': '100'
            }),
            'priority': forms.Select(attrs={'class': 'form-control'}),
            'due_date': forms.DateInput(attrs={
                'type': 'date',
                'class': 'form-control',
                'required': True
            }),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        from django.utils import timezone
        self.fields['due_date'].widget.attrs['min'] = timezone.now().date().strftime('%Y-%m-%d')

class ActivityForm(forms.ModelForm):
    class Meta:
        model = Activity
        fields = ['name', 'priority', 'due_date', 'points']
        widgets = {
            'name': forms.TextInput(attrs={
                'placeholder': 'Enter activity name',
                'class': 'form-control',
                'required': True,
                'maxlength': '100'
            }),
            'priority': forms.Select(attrs={'class': 'form-control'}),
            'due_date': forms.DateInput(attrs={
                'type': 'date',
                'class': 'form-control',
                'required': True
            }),
            'points': forms.NumberInput(attrs={
                'class': 'form-control',
                'min': '0',
                'max': '100',
                'placeholder': 'e.g., 4 points = 2 hours'
            }),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        from django.utils import timezone
        self.fields['due_date'].widget.attrs['min'] = timezone.now().date().strftime('%Y-%m-%d')
