import csv
from django.http import HttpResponse
from django.utils import timezone
from .models import Project, Milestone, Activity, Comment, ProjectLogEntry

def export_csv_data(request):
    """Export all project data as CSV files in a zip archive"""
    import zipfile
    from io import StringIO, BytesIO
    
    # Create a BytesIO buffer to store the zip file
    zip_buffer = BytesIO()
    
    # Create zip file
    with zipfile.ZipFile(zip_buffer, 'w', zipfile.ZIP_DEFLATED) as zip_file:
        # Export Projects
        projects_buffer = StringIO()
        projects_writer = csv.writer(projects_buffer)
        projects_writer.writerow(['ID', 'Name', 'Priority', 'Due Date', 'Created At', 'Is Archived', 'Assigned To'])
        for project in Project.objects.all():
            projects_writer.writerow([
                project.id,
                project.name,
                project.priority,
                project.due_date,
                project.created_at,
                project.is_archived,
                project.assigned_to.username if project.assigned_to else 'Unassigned'
            ])
        zip_file.writestr('projects.csv', projects_buffer.getvalue())

        # Export Milestones
        milestones_buffer = StringIO()
        milestones_writer = csv.writer(milestones_buffer)
        milestones_writer.writerow(['ID', 'Project ID', 'Name', 'Priority', 'Due Date', 'Status', 'Created At'])
        for milestone in Milestone.objects.all():
            milestones_writer.writerow([
                milestone.id,
                milestone.project_id,
                milestone.name,
                milestone.priority,
                milestone.due_date,
                milestone.status,
                milestone.created_at
            ])
        zip_file.writestr('milestones.csv', milestones_buffer.getvalue())

        # Export Activities
        activities_buffer = StringIO()
        activities_writer = csv.writer(activities_buffer)
        activities_writer.writerow(['ID', 'Milestone ID', 'Name', 'Priority', 'Due Date', 'Status', 'Points', 'Created At', 'Assigned To'])
        for activity in Activity.objects.all():
            activities_writer.writerow([
                activity.id,
                activity.milestone_id,
                activity.name,
                activity.priority,
                activity.due_date,
                activity.status,
                activity.points,
                activity.created_at,
                activity.assigned_to.username if activity.assigned_to else 'Unassigned'
            ])
        zip_file.writestr('activities.csv', activities_buffer.getvalue())

        # Export Comments
        comments_buffer = StringIO()
        comments_writer = csv.writer(comments_buffer)
        comments_writer.writerow(['ID', 'Content Type', 'Object ID', 'Text', 'Created At'])
        for comment in Comment.objects.all():
            comments_writer.writerow([
                comment.id,
                comment.content_type,
                comment.object_id,
                comment.text,
                comment.created_at
            ])
        zip_file.writestr('comments.csv', comments_buffer.getvalue())

        # Export Logs
        logs_buffer = StringIO()
        logs_writer = csv.writer(logs_buffer)
        logs_writer.writerow(['ID', 'Project ID', 'Action', 'Description', 'Created At', 'User'])
        for log in ProjectLogEntry.objects.all():
            logs_writer.writerow([
                log.id,
                log.project_id,
                log.action,
                log.description,
                log.created_at,
                log.user.username if log.user else 'System'
            ])
        zip_file.writestr('logs.csv', logs_buffer.getvalue())

    # Create the HTTP response with the zip file
    timestamp = timezone.now().strftime('%Y%m%d_%H%M%S')
    response = HttpResponse(zip_buffer.getvalue(), content_type='application/zip')
    response['Content-Disposition'] = f'attachment; filename=project_data_{timestamp}.zip'
    
    return response
