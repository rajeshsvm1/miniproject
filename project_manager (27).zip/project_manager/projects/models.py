from django.db import models
from django.contrib.contenttypes.fields import GenericRelation, GenericForeignKey
from django.contrib.contenttypes.models import ContentType
from django.db.models import Q, Sum, Count
from django.contrib.auth import get_user_model

class ProjectLogEntry(models.Model):
    ACTION_CHOICES = [
        ('create', 'Created'),
        ('update', 'Updated'),
        ('delete', 'Deleted'),
        ('status', 'Status Change'),
        ('priority', 'Priority Change'),
        ('points', 'Points Change'),
        ('assign', 'Assignment Change'),
        ('archive', 'Archive/Restore'),
        ('comment', 'New Comment'),
    ]
    
    user = models.ForeignKey(get_user_model(), on_delete=models.SET_NULL, null=True, related_name='project_logs')
    action = models.CharField(max_length=20, choices=ACTION_CHOICES)
    content_type = models.ForeignKey(ContentType, on_delete=models.CASCADE, related_name='project_logs')
    object_id = models.PositiveIntegerField()
    content_object = GenericForeignKey('content_type', 'object_id')
    description = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)
    project = models.ForeignKey('Project', on_delete=models.CASCADE, related_name='logs')
    
    class Meta:
        ordering = ['-created_at']
        
    def __str__(self):
        return f"{self.get_action_display()} by {self.user} at {self.created_at}"


class Priority(models.TextChoices):
    HIGH = 'high', 'High Priority'
    MEDIUM = 'medium', 'Medium Priority'
    LOW = 'low', 'Low Priority'

class Status(models.TextChoices):
    OPEN = 'open', 'Open'
    CLOSED = 'closed', 'Closed'

class Project(models.Model):
    name = models.CharField(max_length=100)
    priority = models.CharField(max_length=10, choices=Priority.choices, default=Priority.MEDIUM)
    due_date = models.DateField()
    is_archived = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    # Generic relation to comments
    comments = GenericRelation('Comment', related_query_name='project')
    assigned_to = models.ForeignKey('auth.User', null=True, blank=True, on_delete=models.SET_NULL, related_name='assigned_projects')
    
    class Meta:
        ordering = ['-created_at']
    
    def __str__(self):
        return self.name
    
    @property
    def is_overdue(self):
        from django.utils import timezone
        return self.due_date < timezone.now().date() and not self.is_archived
    
    @property
    def is_closed(self):
        # A project is closed if all its milestones are closed
        milestones = self.milestones.all()
        if not milestones.exists():
            return False
        return all(milestone.is_closed for milestone in milestones)
    
    @property
    def progress_percentage(self):
        total_activities = self.milestones.aggregate(
            total=models.Count('activities')
        )['total'] or 0
        
        if total_activities == 0:
            return 0
            
        completed_activities = self.milestones.aggregate(
            completed=models.Count('activities', filter=models.Q(activities__status=Status.CLOSED))
        )['completed'] or 0
        
        return round((completed_activities / total_activities) * 100)
    
    @property
    def total_points(self):
        """Calculate total points across all activities in this project"""
        return self.milestones.aggregate(
            total=models.Sum('activities__points')
        )['total'] or 0
    
    @property
    def completed_points(self):
        """Calculate completed points across all activities in this project"""
        return self.milestones.aggregate(
            completed=models.Sum('activities__points', filter=models.Q(activities__status=Status.CLOSED))
        )['completed'] or 0
    
    def get_priority_display(self):
        """Get human-readable priority"""
        return dict(Priority.choices)[self.priority]
    
    def log_action(self, user, action, description):
        """Helper method to create a log entry"""
        ProjectLogEntry.objects.create(
            user=user,
            action=action,
            content_type=ContentType.objects.get_for_model(self),
            object_id=self.id,
            description=description,
            project=self
        )

# 👇 PLACE THE MILESTONE MODEL HERE (after Project, before Activity)
class Milestone(models.Model):
    project = models.ForeignKey(Project, on_delete=models.CASCADE, related_name='milestones')
    name = models.CharField(max_length=100)
    priority = models.CharField(max_length=10, choices=Priority.choices, default=Priority.MEDIUM)
    due_date = models.DateField()
    status = models.CharField(max_length=10, choices=Status.choices, default=Status.OPEN)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    # Generic relation to comments
    comments = GenericRelation('Comment', related_query_name='milestone')
    
    class Meta:
        ordering = ['-created_at']
    
    def __str__(self):
        return f"{self.project.name} - {self.name}"
    
    @property
    def is_overdue(self):
        from django.utils import timezone
        return self.due_date < timezone.now().date() and self.status != Status.CLOSED
    
    @property
    def is_closed(self):
        total_activities = self.activities.count()
        if total_activities == 0:
            return False
        return all(activity.status == Status.CLOSED for activity in self.activities.all())
    
    @property
    def progress_percentage(self):
        total_activities = self.activities.count()
        if total_activities == 0:
            return 0
        
        completed_activities = self.activities.filter(status=Status.CLOSED).count()
        return round((completed_activities / total_activities) * 100)
    
    def save(self, *args, **kwargs):
        if self.pk:
            old_instance = Milestone.objects.get(pk=self.pk)
            if old_instance.status != self.status:
                # Log status change if there's a user in the current request
                from django.core.handlers.wsgi import WSGIRequest
                request = getattr(models.Model, '_request', None)
                if isinstance(request, WSGIRequest):
                    self.log_action(
                        user=request.user,
                        action='status',
                        description=f'Changed milestone status from {old_instance.status} to {self.status}'
                    )
        super().save(*args, **kwargs)
        
    def log_action(self, user, action, description):
        """Helper method to create a log entry"""
        ProjectLogEntry.objects.create(
            user=user,
            action=action,
            content_type=ContentType.objects.get_for_model(self),
            object_id=self.id,
            description=description,
            project=self.project
        )

class Activity(models.Model):
    milestone = models.ForeignKey(Milestone, on_delete=models.CASCADE, related_name='activities')
    name = models.CharField(max_length=100)
    description = models.TextField(blank=True)
    priority = models.CharField(max_length=10, choices=Priority.choices, default=Priority.MEDIUM)
    due_date = models.DateField()
    status = models.CharField(max_length=10, choices=Status.choices, default=Status.OPEN)
    points = models.PositiveIntegerField(default=0, help_text="1 point = 30 minutes")
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    assigned_to = models.ForeignKey('auth.User', null=True, blank=True, on_delete=models.SET_NULL, related_name='assigned_activities')
    
    # Generic relation to comments
    comments = GenericRelation('Comment', related_query_name='activity')
    
    @property
    def is_overdue(self):
        from django.utils import timezone
        return self.due_date < timezone.now().date()
    
    @property
    def formatted_points(self):
        if not self.points:
            return None
        hours = self.points / 2  # 1 point = 30 minutes
        return f"{self.points} pts ({hours:.1f} hrs)"
    
    def __str__(self):
        return self.name
    
    def is_assigned_to_user(self, user):
        """Check if an activity is assigned to a user either directly or through project"""
        return (
            self.assigned_to == user or  # Directly assigned
            self.milestone.project.assigned_to == user  # Assigned via project
        )

    def save(self, *args, **kwargs):
        if self.pk:
            old_instance = Activity.objects.get(pk=self.pk)
            if old_instance.status != self.status:
                # Log status change if there's a user in the current request
                from django.core.handlers.wsgi import WSGIRequest
                request = getattr(models.Model, '_request', None)
                if isinstance(request, WSGIRequest):
                    self.log_action(
                        user=request.user,
                        action='status',
                        description=f'Changed activity status from {old_instance.status} to {self.status}'
                    )
        super().save(*args, **kwargs)
        
    def log_action(self, user, action, description):
        """Helper method to create a log entry"""
        ProjectLogEntry.objects.create(
            user=user,
            action=action,
            content_type=ContentType.objects.get_for_model(self),
            object_id=self.id,
            description=description,
            project=self.milestone.project
        )

class MilestoneTemplate(models.Model):
    name = models.CharField(max_length=100)
    description = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    created_by = models.ForeignKey(get_user_model(), on_delete=models.SET_NULL, null=True)

    def __str__(self):
        return self.name
        
    @property
    def total_points(self):
        """Calculate total points across all activities in this template"""
        return self.activities.aggregate(models.Sum('points'))['points__sum'] or 0

class ActivityTemplate(models.Model):
    milestone_template = models.ForeignKey(MilestoneTemplate, on_delete=models.CASCADE, related_name='activities')
    name = models.CharField(max_length=100)
    description = models.TextField(blank=True)
    priority = models.CharField(max_length=10, choices=Priority.choices, default=Priority.MEDIUM)
    points = models.PositiveIntegerField(default=0, help_text="1 point = 30 minutes")
    order = models.PositiveIntegerField(default=0)

    class Meta:
        ordering = ['order']

    def __str__(self):
        return f"{self.milestone_template.name} - {self.name}"

class Comment(models.Model):
    # Generic foreign key to link comments to any model
    content_type = models.ForeignKey(ContentType, on_delete=models.CASCADE)
    object_id = models.PositiveIntegerField()
    content_object = GenericForeignKey('content_type', 'object_id')
    
    user = models.ForeignKey(get_user_model(), on_delete=models.SET_NULL, null=True, related_name='comments')
    text = models.TextField(max_length=1000)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        ordering = ['-created_at']
    
    def __str__(self):
        return f"Comment on {self.content_object}: {self.text[:50]}..."

class Notification(models.Model):
    NOTIFICATION_TYPES = [
        ('comment', 'New Comment'),
        ('status', 'Status Change'),
        ('assign', 'Assignment'),
        ('priority', 'Priority Change'),
    ]
    
    user = models.ForeignKey(get_user_model(), on_delete=models.CASCADE, related_name='notifications')
    notification_type = models.CharField(max_length=20, choices=NOTIFICATION_TYPES)
    content_type = models.ForeignKey(ContentType, on_delete=models.CASCADE)
    object_id = models.PositiveIntegerField()
    content_object = GenericForeignKey('content_type', 'object_id')
    message = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)
    is_read = models.BooleanField(default=False)
    
    class Meta:
        ordering = ['-created_at']
    
    def __str__(self):
        return f"{self.get_notification_type_display()} for {self.user.username}"
        
    @classmethod
    def create_notification(cls, user, notification_type, obj, message):
        """Helper method to create a notification"""
        content_type = ContentType.objects.get_for_model(obj)
        return cls.objects.create(
            user=user,
            notification_type=notification_type,
            content_type=content_type,
            object_id=obj.id,
            message=message
        )
