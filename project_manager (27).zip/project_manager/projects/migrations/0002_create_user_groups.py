from django.conf import settings
from django.db import migrations


def create_user_groups(apps, schema_editor):
	"""Create initial user groups if they don't already exist."""
	Group = apps.get_model('auth', 'Group')
	for name in ['Admin', 'Developer']:
		Group.objects.get_or_create(name=name)


def remove_user_groups(apps, schema_editor):
	"""Reverse operation: remove the created groups (safe cleanup)."""
	Group = apps.get_model('auth', 'Group')
	Group.objects.filter(name__in=['Admin', 'Developer']).delete()


class Migration(migrations.Migration):
	# NOTE: Although numbered 0002, this migration depends on 0005 to avoid a split
	# branch in the graph (previously caused conflict with 0005_add_activity_description).
	# Django ignores numeric prefixes for ordering and uses explicit dependencies.
	dependencies = [
		('projects', '0005_add_activity_description'),
		migrations.swappable_dependency(settings.AUTH_USER_MODEL),
	]

	operations = [
		migrations.RunPython(create_user_groups, remove_user_groups),
	]
