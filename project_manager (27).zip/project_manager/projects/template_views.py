from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.views.decorators.http import require_http_methods
from django.http import JsonResponse
from django.contrib import messages
from django.db import transaction
from django.utils import timezone
from django.urls import reverse

from .models import MilestoneTemplate, ActivityTemplate, Milestone, Activity
from .decorators import admin_required

@login_required
@admin_required
def template_list(request):
    """Show list of milestone templates"""
    templates = MilestoneTemplate.objects.all().order_by('-created_at')
    return render(request, 'projects/templates/template_list.html', {
        'templates': templates,
    })

@login_required
@admin_required
def add_template(request):
    """Add a new milestone template"""
    if request.method == 'POST':
        name = request.POST.get('name')
        description = request.POST.get('description', '')
        
        if not name:
            return JsonResponse({
                'status': 'error',
                'message': 'Template name is required'
            })
        
        template = MilestoneTemplate.objects.create(
            name=name,
            description=description,
            created_by=request.user
        )
        
        if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
            return JsonResponse({
                'status': 'success',
                'message': 'Template created successfully',
                'template': {
                    'id': template.id,
                    'name': template.name
                }
            })
        
        messages.success(request, 'Template created successfully')
        return redirect('projects:template_activities', template_id=template.id)
    
    return render(request, 'projects/templates/add_template.html')

@login_required
@admin_required
def template_activities(request, template_id):
    """Manage activities for a milestone template"""
    template = get_object_or_404(MilestoneTemplate, id=template_id)
    
    if request.method == 'POST':
        name = request.POST.get('name')
        priority = request.POST.get('priority')
        points = request.POST.get('points', 0)
        order = request.POST.get('order', 0)
        
        if not name:
            return JsonResponse({
                'status': 'error',
                'message': 'Activity name is required'
            })
        
        activity = ActivityTemplate.objects.create(
            milestone_template=template,
            name=name,
            priority=priority,
            points=points,
            order=order
        )
        
        if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
            return JsonResponse({
                'status': 'success',
                'message': 'Activity added successfully',
                'activity': {
                    'id': activity.id,
                    'name': activity.name,
                    'priority': activity.get_priority_display(),
                    'points': activity.points
                }
            })
        
        messages.success(request, 'Activity added successfully')
        return redirect('projects:template_activities', template_id=template.id)
    
    return render(request, 'projects/templates/template_activities.html', {
        'template': template,
        'activities': template.activities.all()
    })

@login_required
@admin_required
def delete_template(request, template_id):
    """Delete a milestone template"""
    if request.method == 'POST':
        template = get_object_or_404(MilestoneTemplate, id=template_id)
        template.delete()
        messages.success(request, 'Template deleted successfully')
        return JsonResponse({'status': 'success'})
    return JsonResponse({'status': 'error', 'message': 'Invalid request method'})

@login_required
@admin_required
def delete_template_activity(request, activity_id):
    """Delete an activity from a template"""
    if request.method == 'POST':
        activity = get_object_or_404(ActivityTemplate, id=activity_id)
        activity.delete()
        messages.success(request, 'Activity deleted successfully')
        return JsonResponse({'status': 'success'})
    return JsonResponse({'status': 'error', 'message': 'Invalid request method'})

@login_required
@admin_required
@require_http_methods(["POST"])
def apply_template(request, template_id, milestone_id):
    """Apply a template to a milestone"""
    import logging
    logger = logging.getLogger(__name__)
    
    logger.info(f"Applying template {template_id} to milestone {milestone_id}")
    logger.info(f"Request method: {request.method}")
    logger.info(f"Request headers: {request.headers}")
    
    try:
        template = get_object_or_404(MilestoneTemplate, id=template_id)
        milestone = get_object_or_404(Milestone, id=milestone_id)
        
        logger.info(f"Found template: {template.name} with {template.activities.count()} activities")
        logger.info(f"Found milestone: {milestone.name}")
        
        with transaction.atomic():
            created_activities = []
            template_activities = template.activities.all()
            logger.info(f"Template activities to create: {[a.name for a in template_activities]}")
            
            for template_activity in template_activities:
                logger.info(f"Creating activity from template: {template_activity.name}")
                activity = Activity.objects.create(
                    milestone=milestone,
                    name=template_activity.name,
                    description=template_activity.description,
                    priority=template_activity.priority,
                    points=template_activity.points,
                    due_date=milestone.due_date,  # Default to milestone due date
                    status='open'
                )
                created_activities.append({
                    'name': activity.name,
                    'id': activity.id,
                    'description': activity.description
                })
                logger.info(f"Created activity: {activity.name} (ID: {activity.id})")
            
        logger.info(f"Successfully created {len(created_activities)} activities")
        
        success_message = f'Applied template "{template.name}" to milestone "{milestone.name}"'
        messages.success(request, success_message)
        
        response_data = {
            'status': 'success',
            'message': success_message,
            'template_name': template.name,
            'milestone_name': milestone.name,
            'activities': created_activities
        }
        logger.info(f"Sending response: {response_data}")
        return JsonResponse(response_data)
        
    except Exception as e:
        logger.error(f"Error applying template: {str(e)}", exc_info=True)
        return JsonResponse({
            'status': 'error',
            'message': f'Error applying template: {str(e)}'
        }, status=500)

@login_required
@admin_required
def add_template_activity(request, template_id):
    """Add a new activity to a template"""
    template = get_object_or_404(MilestoneTemplate, id=template_id)
    
    if request.method == 'POST':
        name = request.POST.get('name')
        description = request.POST.get('description', '')
        priority = request.POST.get('priority', 'medium')
        points = request.POST.get('points', 1)
        
        if not name:
            return JsonResponse({
                'status': 'error',
                'message': 'Activity name is required'
            })
        
        order = template.activities.count()  # Add to the end
        activity = ActivityTemplate.objects.create(
            milestone_template=template,
            name=name,
            description=description,
            priority=priority,
            points=points,
            order=order
        )
        
        if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
            return JsonResponse({
                'status': 'success',
                'message': 'Activity added successfully'
            })
        
        messages.success(request, 'Activity added successfully')
        return redirect('projects:template_activities', template_id=template.id)
    
    template_name = 'projects/templates/add_template_activity.html'
    if request.headers.get('X-Requested-With') != 'XMLHttpRequest':
        template_name = 'projects/templates/add_template_activity_page.html'
    return render(request, template_name, {
        'template': template
    })

@login_required
@admin_required
def edit_template_activity(request, activity_id):
    """Edit an existing template activity"""
    activity = get_object_or_404(ActivityTemplate, id=activity_id)
    
    if request.method == 'POST':
        name = request.POST.get('name')
        description = request.POST.get('description', '')
        priority = request.POST.get('priority', 'medium')
        points = request.POST.get('points', 1)
        
        if not name:
            return JsonResponse({
                'status': 'error',
                'message': 'Activity name is required'
            })
        
        try:
            points = int(points)
            if points < 1 or points > 10:
                return JsonResponse({
                    'status': 'error',
                    'message': 'Points must be between 1 and 10'
                })
        except (ValueError, TypeError):
            return JsonResponse({
                'status': 'error',
                'message': 'Invalid points value'
            })
        
        activity.name = name
        activity.description = description
        activity.priority = priority
        activity.points = points
        activity.save()
        
        if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
            return JsonResponse({
                'status': 'success',
                'message': 'Activity updated successfully'
            })
        
        messages.success(request, 'Activity updated successfully')
        return redirect('projects:template_activities', template_id=activity.milestone_template.id)
    
    template_name = 'projects/templates/add_template_activity.html'
    if request.headers.get('X-Requested-With') != 'XMLHttpRequest':
        template_name = 'projects/templates/add_template_activity_page.html'
    return render(request, template_name, {
        'activity': activity,
        'template': activity.milestone_template
    })

@login_required
@admin_required
@require_http_methods(["POST"])
def reorder_template_activities(request, template_id):
    """Update the order of template activities"""
    template = get_object_or_404(MilestoneTemplate, id=template_id)
    # Support both JSON body (from fetch with application/json) and form-encoded
    activity_ids = []
    if request.content_type == 'application/json':
        import json
        try:
            payload = json.loads(request.body.decode('utf-8'))
            # Front-end sends { activities: [ids...] }
            activity_ids = payload.get('activities', []) or []
        except Exception:
            return JsonResponse({'status': 'error', 'message': 'Invalid JSON payload'}, status=400)
    else:
        # Accept either activity[] list or single activities comma-separated
        activity_ids = request.POST.getlist('activity[]') or request.POST.getlist('activities')
        if not activity_ids:
            csv = request.POST.get('activities')
            if csv:
                activity_ids = [a for a in csv.split(',') if a]

    # Validate ids are integers
    try:
        activity_ids = [int(a) for a in activity_ids]
    except ValueError:
        return JsonResponse({'status': 'error', 'message': 'Activity ids must be integers'}, status=400)

    if not activity_ids:
        return JsonResponse({'status': 'error', 'message': 'No activities provided'}, status=400)

    # Ensure all belong to this template
    existing = set(ActivityTemplate.objects.filter(milestone_template=template, id__in=activity_ids).values_list('id', flat=True))
    missing = [a for a in activity_ids if a not in existing]
    if missing:
        return JsonResponse({'status': 'error', 'message': f'Activities not found: {missing}'}, status=400)

    with transaction.atomic():
        for index, activity_id in enumerate(activity_ids):
            ActivityTemplate.objects.filter(id=activity_id).update(order=index)

    return JsonResponse({'status': 'success', 'order': activity_ids})
