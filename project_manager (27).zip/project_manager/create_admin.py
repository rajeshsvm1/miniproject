import os
import django

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'project_manager.settings')
django.setup()

from django.contrib.auth.models import User
from django.db import IntegrityError

username = 'admin'
password = 'Admin@123'
email = 'admin@example.com'

try:
    # Delete existing superuser if it exists
    User.objects.filter(is_superuser=True).delete()
    
    # Create new superuser
    superuser = User.objects.create_superuser(
        username=username,
        email=email,
        password=password
    )
    print(f"\nSuperuser created successfully!\nUsername: {username}\nPassword: {password}\n")
except IntegrityError:
    print("Error: Username already exists")
except Exception as e:
    print(f"Error creating superuser: {str(e)}")
