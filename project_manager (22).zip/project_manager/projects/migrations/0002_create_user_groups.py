from django.db import migrations
from django.contrib.auth.models import Group, Permission
from django.contrib.contenttypes.models import ContentType

def create_groups(apps, schema_editor):
    # Create Admin group
    admin_group, created = Group.objects.get_or_create(name='Admin')
    
    # Create Developer group
    developer_group, created = Group.objects.get_or_create(name='Developer')
    
    # Get all the models from our app
    Project = apps.get_model('projects', 'Project')
    Milestone = apps.get_model('projects', 'Milestone')
    Activity = apps.get_model('projects', 'Activity')
    
    # Get content types for our models
    project_ct = ContentType.objects.get_for_model(Project)
    milestone_ct = ContentType.objects.get_for_model(Milestone)
    activity_ct = ContentType.objects.get_for_model(Activity)
    
    # Get all permissions for our models
    project_permissions = Permission.objects.filter(content_type=project_ct)
    milestone_permissions = Permission.objects.filter(content_type=milestone_ct)
    activity_permissions = Permission.objects.filter(content_type=activity_ct)
    
    # Add all permissions to Admin group
    admin_group.permissions.add(*project_permissions)
    admin_group.permissions.add(*milestone_permissions)
    admin_group.permissions.add(*activity_permissions)
    
    # Add view and change permissions to Developer group
    for ct in [project_ct, milestone_ct, activity_ct]:
        developer_group.permissions.add(
            Permission.objects.get(content_type=ct, codename='view_' + ct.model),
            Permission.objects.get(content_type=ct, codename='change_' + ct.model),
            Permission.objects.get(content_type=ct, codename='add_' + ct.model)
        )

def remove_groups(apps, schema_editor):
    Group.objects.filter(name__in=['Admin', 'Developer']).delete()

class Migration(migrations.Migration):
    dependencies = [
        ('projects', '0001_initial'),
    ]

    operations = [
        migrations.RunPython(create_groups, remove_groups),
    ]