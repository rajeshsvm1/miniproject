from django.contrib import admin
from .models import Project, Milestone, Activity, Comment

@admin.register(Project)
class ProjectAdmin(admin.ModelAdmin):
    list_display = ['name', 'priority', 'due_date', 'is_archived', 'created_at']
    list_filter = ['priority', 'is_archived', 'created_at']
    search_fields = ['name']
    date_hierarchy = 'due_date'

@admin.register(Milestone)
class MilestoneAdmin(admin.ModelAdmin):
    list_display = ['name', 'project', 'priority', 'due_date', 'created_at']
    list_filter = ['priority', 'created_at', 'project']
    search_fields = ['name', 'project__name']

@admin.register(Activity)
class ActivityAdmin(admin.ModelAdmin):
    list_display = ['name', 'milestone', 'priority', 'status', 'points', 'due_date']
    list_filter = ['priority', 'status', 'created_at']
    search_fields = ['name', 'milestone__name', 'milestone__project__name']

@admin.register(Comment)
class CommentAdmin(admin.ModelAdmin):
    list_display = ['content_object', 'text', 'created_at']
    list_filter = ['created_at']
