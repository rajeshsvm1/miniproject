// AJAX for assigning user to project
function assignUserToProject(projectId, userId, selectElem) {
    console.log(`Assigning user ${userId} to project ${projectId}`);
    
    // Save the previous value before making any changes
    if (selectElem) {
        selectElem.setAttribute('data-previous-value', selectElem.value);
    }
    
    // Disable the select element while the request is in progress
    if (selectElem) selectElem.disabled = true;
    
    fetch(`/projects/api/project/${projectId}/assign-user/`, {
        method: 'POST',
        headers: {
            'X-Requested-With': 'XMLHttpRequest',
            'X-CSRFToken': getCSRFToken(),
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        credentials: 'same-origin',
        body: `user_id=${encodeURIComponent(userId)}`
    })
    .then(response => {
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        return response.json();
    })
    .then(data => {
        console.log('Response data:', data);
        if (data.status === 'success') {
            showToast(data.message || 'User assigned successfully!', 'success', 5000);
            // Update the label for 'Assigned to' in the UI
            let assignedName = data.assigned_to || selectElem?.options[selectElem.selectedIndex]?.text || 'Unassigned';
            if (selectElem) {
                // Try to find the label in the same <p> as the select
                let parentP = selectElem.closest('p');
                if (parentP) {
                    // Remove any text nodes after the select and append the new label
                    let labelSpan = parentP.querySelector('.assigned-label');
                    if (!labelSpan) {
                        labelSpan = document.createElement('span');
                        labelSpan.className = 'assigned-label';
                        parentP.appendChild(labelSpan);
                    }
                    labelSpan.textContent = ` → ${assignedName}`;
                }
            }
        } else {
            showToast(data.message || 'Failed to assign user', 'error', 4000);
            // Reset the select to its previous value on error
            if (selectElem) {
                const previousValue = selectElem.getAttribute('data-previous-value') || '';
                selectElem.value = previousValue;
            }
        }
    })
    .catch(error => {
        console.error('Error:', error);
        showToast(`Error assigning user: ${error.message}`, 'error', 4000);
        // Reset the select to its previous value on error
        if (selectElem) {
            const previousValue = selectElem.getAttribute('data-previous-value') || '';
            selectElem.value = previousValue;
        }
    })
    .finally(() => {
        // Re-enable the select element
        if (selectElem) selectElem.disabled = false;
    });
}
window.assignUserToProject = assignUserToProject;
