// Restore Project (global function for all templates)
function restoreProject(projectId) {
    if (!confirm('Are you sure you want to restore this project?')) return;
    fetch(`/projects/api/project/${projectId}/restore/`, {
        method: 'POST',
        headers: {
            'X-Requested-With': 'XMLHttpRequest',
            'X-CSRFToken': getCSRFToken()
        },
        credentials: 'same-origin'
    })
    .then(response => response.json())
    .then(data => {
        if (data.status === 'success') {
            showToast(data.message || 'Project restored successfully', 'success');
            setTimeout(() => window.location.reload(), 1000);
        } else {
            showToast(data.message || 'Failed to restore project', 'error');
        }
    })
    .catch(error => {
        showToast('An error occurred while restoring project', 'error');
    });
}

// Ensure restoreProject is available globally
window.restoreProject = restoreProject;
// Ensure archiveProject is available globally
window.archiveProject = archiveProject;
// Archive Project (global function for all templates)
function archiveProject(projectId) {
    if (!confirm('Are you sure you want to archive this project?')) return;
    fetch(`/projects/api/project/${projectId}/archive/`, {
        method: 'POST',
        headers: {
            'X-Requested-With': 'XMLHttpRequest',
            'X-CSRFToken': getCSRFToken()
        },
        credentials: 'same-origin'
    })
    .then(response => response.json())
    .then(data => {
        if (data.status === 'success') {
            showToast(data.message || 'Project archived successfully', 'success');
            setTimeout(() => window.location.reload(), 1000);
        } else {
            showToast(data.message || 'Failed to archive project', 'error');
        }
    })
    .catch(error => {
        showToast('An error occurred while archiving project', 'error');
    });
}
// Get CSRF token for Django
function getCSRFToken() {
    // Try form input first
    const tokenElement = document.querySelector('[name=csrfmiddlewaretoken]');
    if (tokenElement) return tokenElement.value;
    // Fallback to meta tag
    const meta = document.querySelector('meta[name="csrf-token"]');
    return meta ? meta.content : '';
}

// Complete modal system for Django forms
function openModal(url, title) {
    let modal = document.getElementById('dynamicModal');
    if (!modal) {
        modal = createModal();
        document.body.appendChild(modal);
    }
    
    const modalTitle = modal.querySelector('.modal-title');
    const modalBody = modal.querySelector('.modal-body');
    
    modalTitle.textContent = title;
    modalBody.innerHTML = '<div class="loading">Loading...</div>';
    
    // Show modal
    modal.style.display = 'block';
    modal.classList.add('show');
    
    // Load form content via AJAX
    fetch(url, {
        headers: {
            'X-Requested-With': 'XMLHttpRequest',
        }
    })
    .then(response => {
        if (!response.ok) {
            throw new Error(`HTTP ${response.status}: ${response.statusText}`);
        }
        return response.text();
    })
    .then(html => {
        modalBody.innerHTML = html;
        setupModalForm(modal);
    })
    .catch(error => {
        modalBody.innerHTML = `<div class="error">Error loading form: ${error.message}</div>`;
        console.error('Error:', error);
    });
}

function createModal() {
    const modal = document.createElement('div');
    modal.id = 'dynamicModal';
    modal.className = 'modal';
    modal.innerHTML = `
        <div class="modal-content">
            <div class="modal-header">
                <h3 class="modal-title">Modal Title</h3>
                <span class="modal-close" onclick="closeModal()">&times;</span>
            </div>
            <div class="modal-body">
                <!-- Content will be loaded here -->
            </div>
        </div>
    `;
    
    // Close modal when clicking outside
    modal.onclick = function(event) {
        if (event.target === modal) {
            closeModal();
        }
    };
    
    return modal;
}

function setupModalForm(modal) {
    const form = modal.querySelector('form');
    if (form) {
        form.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const formData = new FormData(form);
            const url = form.action;
            
            // Show loading state
            const submitBtn = form.querySelector('button[type="submit"]');
            const originalText = submitBtn.textContent;
            submitBtn.textContent = 'Saving...';
            submitBtn.disabled = true;
            
            fetch(url, {
                method: 'POST',
                body: formData,
                headers: {
                    'X-Requested-With': 'XMLHttpRequest',
                    'X-CSRFToken': getCSRFToken()
                }
            })
            .then(response => {
                if (!response.ok) {
                    throw new Error(`HTTP ${response.status}: ${response.statusText}`);
                }
                return response.json();
            })
            .then(data => {
                if (data.status === 'success') {
                    closeModal();
                    showToast(data.message, 'success');
                    // Refresh current page to show new item
                    setTimeout(() => {
                        window.location.reload();
                    }, 1000);
                } else {
                    displayFormErrors(form, data.errors || {});
                    if (data.message) {
                        showToast(data.message, 'error');
                    }
                }
            })
            .catch(error => {
                console.error('Error:', error);
                showToast('An error occurred while saving: ' + error.message, 'error');
            })
            .finally(() => {
                // Reset button state
                submitBtn.textContent = originalText;
                submitBtn.disabled = false;
            });
        });
    }

    function setupModalForm(modal) {
        const form = modal.querySelector('form');
        if (form) {
            let isSubmitting = false;
            form.addEventListener('submit', function(e) {
                e.preventDefault();
                if (isSubmitting) return; // Prevent double submit
                isSubmitting = true;
                const formData = new FormData(form);
                const url = form.action;
                // Show loading state
                const submitBtn = form.querySelector('button[type="submit"]');
                const originalText = submitBtn.textContent;
                submitBtn.textContent = 'Saving...';
                submitBtn.disabled = true;
                fetch(url, {
                    method: 'POST',
                    body: formData,
                    headers: {
                        'X-Requested-With': 'XMLHttpRequest',
                        'X-CSRFToken': getCSRFToken()
                    }
                })
                .then(response => {
                    if (!response.ok) {
                        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
                    }
                    return response.json();
                })
                .then(data => {
                    if (data.status === 'success') {
                        closeModal();
                        showToast(data.message, 'success');
                        // Refresh current page to show new item
                        setTimeout(() => {
                            window.location.reload();
                        }, 1000);
                    } else {
                        displayFormErrors(form, data.errors || {});
                        if (data.message) {
                            showToast(data.message, 'error');
                        }
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    showToast('An error occurred while saving: ' + error.message, 'error');
                })
                .finally(() => {
                    submitBtn.textContent = originalText;
                    submitBtn.disabled = false;
                    isSubmitting = false;
                });
            });
        }
    }
}

function displayFormErrors(form, errors) {
    // Clear previous errors
    form.querySelectorAll('.error-message').forEach(el => el.remove());
    
    // Display new errors
    Object.keys(errors).forEach(fieldName => {
        const field = form.querySelector(`[name="${fieldName}"]`);
        if (field && errors[fieldName].length > 0) {
            const errorSpan = document.createElement('span');
            errorSpan.className = 'error-message';
            errorSpan.textContent = errors[fieldName][0];
            field.parentNode.appendChild(errorSpan);
        }
    });
}

function closeModal() {
    const modal = document.getElementById('dynamicModal');
    if (modal) {
        modal.style.display = 'none';
        modal.classList.remove('show');
    }
}

// Toast notifications
function showToast(message, type = 'info', duration = 3000) {
    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    toast.textContent = message;
    
    document.body.appendChild(toast);
    
    setTimeout(() => {
        toast.style.animation = 'slideOutRight 0.3s ease';
        setTimeout(() => toast.remove(), 300);
    }, duration);
}

// Initialize when DOM loads
document.addEventListener('DOMContentLoaded', function() {
    // Add click handlers for all modal buttons
    document.querySelectorAll('[data-modal-url]').forEach(button => {
        button.addEventListener('click', function(e) {
            e.preventDefault();
            const url = this.dataset.modalUrl;
            const title = this.dataset.modalTitle || 'Add Item';
            openModal(url, title);
        });
    });
    
    // Your existing initialization code...
    addSearchBar();
    initializeProgressBars();
    addKeyboardNavigation();
    showDjangoMessages();
});

// Initialize event handlers when DOM loads
document.addEventListener('DOMContentLoaded', function() {
    // Add click handlers for all cards
    document.querySelectorAll('.card[data-href]').forEach(card => {
        card.addEventListener('click', function(e) {
            // Don't navigate if:
            // 1. Clicking on buttons or links
            // 2. Clicking on selectable text
            // 3. User has text selected
            if (e.target.closest('button, a, select, .project-actions') || 
                e.target.closest('.card-text') ||
                window.getSelection().toString().trim().length > 0) {
                return;
            }
            
            const href = this.dataset.href;
            if (href) {
                window.location.href = href;
            }
        });
    });
    
    // Your other initialization code...
    addSearchBar();
    initializeProgressBars();
    addKeyboardNavigation();
    showDjangoMessages();
});


function addMilestoneComment(event, milestoneId) {
    event.preventDefault();
    const form = event.target;
    // If milestoneId is not passed, try to get from data attribute
    if (!milestoneId && form.dataset.milestoneId) {
        milestoneId = form.dataset.milestoneId;
    }
    const textarea = form.querySelector('.milestoneCommentText');
    const commentText = textarea.value.trim();
    if (!commentText) {
        showToast('Comment cannot be empty', 'warning');
        return;
    }
    const formData = new FormData();
    formData.append('comment', commentText);
    // Get CSRF token from the form
    const csrfTokenInput = form.querySelector('[name=csrfmiddlewaretoken]');
    formData.append('csrfmiddlewaretoken', csrfTokenInput ? csrfTokenInput.value : getCSRFToken());
    fetch(`/projects/api/milestone/${milestoneId}/add-comment/`, {
        method: 'POST',
        body: formData,
        headers: {
            'X-Requested-With': 'XMLHttpRequest'
        }
    })
    .then(response => response.json())
    .then(data => {
        if (data.status === 'success') {
            showToast(data.message, 'success');
            // Add comment to the list dynamically
            const commentsList = form.closest('.milestone-comments').querySelector(`#milestone-comments-list-${milestoneId}`);
            if (commentsList) {
                if (commentsList.querySelector('p')) {
                    // Remove "no comments" message
                    commentsList.innerHTML = '';
                }
                commentsList.insertAdjacentHTML('afterbegin', data.comment_html);
            }
            // Clear the form
            textarea.value = '';
        } else {
            showToast(data.message || 'Failed to add comment', 'error');
        }
    })
    .catch(error => {
        console.error('Error:', error);
        showToast('An error occurred while adding comment', 'error');
    });
}

function clearMilestoneComment(btn) {
    // btn is the button inside the form
    const form = btn.closest('form');
    if (form) {
        const textarea = form.querySelector('.milestoneCommentText');
        if (textarea) textarea.value = '';
    }
}

function getCSRFToken() {
    const token = document.querySelector('[name=csrfmiddlewaretoken]');
    return token ? token.value : '';
}

