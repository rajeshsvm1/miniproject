from django.core.management.base import BaseCommand
from django.contrib.auth import get_user_model
from django.contrib.auth.models import Group

class Command(BaseCommand):
    help = 'Assign a user to Admin or Developer group'

    def add_arguments(self, parser):
        parser.add_argument('username', type=str, help='Username to assign to a group')
        parser.add_argument('group', type=str, choices=['admin', 'developer'], help='Group to assign (admin or developer)')

    def handle(self, *args, **kwargs):
        User = get_user_model()
        username = kwargs['username']
        group_name = kwargs['group'].capitalize()
        
        try:
            # Get the user and group
            user = User.objects.get(username=username)
            group = Group.objects.get(name=group_name)
            
            # Remove from any existing Admin/Developer groups
            user.groups.remove(Group.objects.get(name='Admin'))
            user.groups.remove(Group.objects.get(name='Developer'))
            
            # Add to the specified group
            user.groups.add(group)
            
            self.stdout.write(
                self.style.SUCCESS(f'Successfully assigned user "{username}" to {group_name} group')
            )
            
        except User.DoesNotExist:
            self.stdout.write(
                self.style.ERROR(f'User "{username}" does not exist')
            )
        except Group.DoesNotExist:
            self.stdout.write(
                self.style.ERROR(f'Group "{group_name}" does not exist. Run setup_groups_users first.')
            )
