from django.contrib.auth import get_user_model
from django.views.decorators.http import require_POST
from django.http import JsonResponse, HttpResponseBadRequest
from django.contrib.auth.decorators import login_required
from django.views.decorators.csrf import csrf_exempt
from .models import Project
import logging

logger = logging.getLogger(__name__)

@csrf_exempt
@require_POST
@login_required
def assign_project_user(request, project_id):
    logger.info(f"Starting assign_project_user: project_id={project_id}")
    logger.debug(f"POST data: {request.POST}")
    
    # Get user_id from POST data
    user_id = request.POST.get('user_id')
    logger.debug(f"Processing assignment: user_id={user_id}, project_id={project_id}")
    
    try:
        if not user_id:
            error_msg = "No user_id provided in POST data."
            logger.error(error_msg)
            return JsonResponse({'status': 'error', 'message': error_msg})
            
        # Get the project first
        try:
            project = Project.objects.get(pk=project_id)
            logger.debug(f"Found project: {project}")
        except Project.DoesNotExist as e:
            error_msg = f"Project not found with id {project_id}"
            logger.error(error_msg)
            return JsonResponse({'status': 'error', 'message': error_msg})
            
        # If user_id is '0' or empty, unassign
        if user_id == '0' or not user_id:
            project.assigned_to = None
            project.save()
            logger.info(f"Unassigned project {project}")
            return JsonResponse({
                'status': 'success',
                'message': 'Project unassigned successfully',
                'assigned_to': None
            })
            
        # Get the user
        try:
            user = get_user_model().objects.get(pk=user_id)
            logger.debug(f"Found user: {user}")
        except get_user_model().DoesNotExist as e:
            error_msg = f"User not found with id {user_id}"
            logger.error(error_msg)
            return JsonResponse({'status': 'error', 'message': error_msg})
            
        # Assign the user
        project.assigned_to = user
        project.save()
        logger.info(f"Successfully assigned user {user} to project {project}")
        
        return JsonResponse({
            'status': 'success',
            'message': f'Project assigned to {user.get_full_name() or user.username}',
            'assigned_to': user.get_full_name() or user.username
        })
        
    except Exception as e:
        error_msg = f"Unexpected error while assigning project: {str(e)}"
        logger.error(error_msg, exc_info=True)
        return JsonResponse({'status': 'error', 'message': error_msg}, status=500)
