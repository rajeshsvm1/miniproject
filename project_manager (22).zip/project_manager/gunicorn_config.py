bind = "0.0.0.0:8000"
workers = 3  # Number of worker processes = (2 x CPU cores) + 1
timeout = 120  # Timeout in seconds
accesslog = "gunicorn_access.log"
errorlog = "gunicorn_error.log"
capture_output = True
loglevel = "info"
