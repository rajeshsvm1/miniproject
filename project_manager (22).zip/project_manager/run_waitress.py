from waitress import serve
from project_manager.wsgi import application
import os

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'project_manager.settings_local_prod')

if __name__ == '__main__':
    print('Starting Waitress server on http://localhost:8000')
    serve(application, host='0.0.0.0', port=8000, threads=4)
