from django.shortcuts import render, get_object_or_404, redirect
from django.http import JsonResponse
from django.contrib import messages
from django.utils import timezone
from django.db.models import Q, Count, Sum
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_http_methods
from .models import Project, Milestone, Activity, Comment, Priority, Status
from .forms import ProjectForm, MilestoneForm, ActivityForm  # Import from forms.py
from datetime import date, timedelta
from django.contrib.auth.decorators import login_required
from django.contrib.auth import get_user_model
import json
from django.contrib.contenttypes.models import ContentType
from .assign_api import assign_project_user

@login_required
def assigned_to_me(request):
    projects = Project.objects.filter(assigned_to=request.user, is_archived=False)
    context = {
        'projects': projects,
        'assigned_to_me': True,
        'archived': False,
        'search_query': '',
    }
    return render(request, 'projects/project_list.html', context)

@require_http_methods(["GET", "POST"])
def add_milestone(request, project_id):
    """Add new milestone via modal form"""
    project = get_object_or_404(Project, id=project_id)
    if request.method == 'POST':
        form = MilestoneForm(request.POST)
        if form.is_valid():
            milestone = form.save(commit=False)
            milestone.project = project
            milestone.save()
            if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                return JsonResponse({
                    'status': 'success',
                    'message': 'Milestone created successfully'
                })
            else:
                messages.success(request, 'Milestone created successfully')
                return redirect('projects:milestone_list', project_id=project.id)
        else:
            if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                return JsonResponse({
                    'status': 'error',
                    'errors': form.errors
                })
    else:
        form = MilestoneForm()
    return render(request, 'projects/add_milestone_modal.html', {
        'form': form,
        'project': project
    })
from django.shortcuts import render, get_object_or_404, redirect
from django.http import JsonResponse
from django.contrib import messages
from django.utils import timezone
from django.db.models import Q, Count, Sum
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_http_methods
from .models import Project, Milestone, Activity, Comment, Priority, Status
from .forms import ProjectForm, MilestoneForm, ActivityForm  # Import from forms.py
from datetime import date, timedelta
from django.contrib.auth.decorators import login_required
from django.contrib.auth.decorators import login_required
import json
from django.contrib.contenttypes.models import ContentType



@login_required
def dashboard(request):
    """Dashboard view with comprehensive statistics and project breakdown"""
    # Calculate statistics
    total_projects = Project.objects.count()
    active_projects = Project.objects.filter(is_archived=False).count()
    archived_projects = Project.objects.filter(is_archived=True).count()
    
    # Activity statistics
    total_activities = Activity.objects.count()
    completed_activities = Activity.objects.filter(status=Status.CLOSED).count()
    overdue_activities = Activity.objects.filter(
        due_date__lt=timezone.now().date(),
        status=Status.OPEN
    ).count()
    
    # Points statistics
    total_points = Activity.objects.aggregate(Sum('points'))['points__sum'] or 0
    completed_points = Activity.objects.filter(status=Status.CLOSED).aggregate(Sum('points'))['points__sum'] or 0
    
    # Recent comments
    recent_comments = Comment.objects.select_related('content_type')[:5]
    
    # Project breakdown for time tracking
    project_breakdown = []
    for project in Project.objects.filter(is_archived=False):
        if project.total_points > 0:  # This line was causing the error
            project_breakdown.append({
                'id': project.id,  # Add project ID for links
                'name': project.name,
                'total': project.total_points,
                'completed': project.completed_points,
                'percentage': round((project.completed_points / project.total_points) * 100) if project.total_points > 0 else 0,
                'estimated_hours': project.total_points // 2
            })
    
    context = {
        'total_projects': total_projects,
        'active_projects': active_projects,
        'archived_projects': archived_projects,
        'total_activities': total_activities,
        'completed_activities': completed_activities,
        'overdue_activities': overdue_activities,
        'total_points': total_points,
        'completed_points': completed_points,
        'estimated_hours': total_points // 2,
        'completion_rate': round((completed_activities / max(total_activities, 1)) * 100),
        'recent_comments': recent_comments,
        'project_breakdown': project_breakdown,
    }
    
    return render(request, 'projects/dashboard.html', context)

@login_required
def project_list(request):
    """List projects (active or archived) with search functionality"""
    archived = request.GET.get('archived', 'false') == 'true'
    projects = Project.objects.filter(is_archived=archived)
    users = get_user_model().objects.all()
    # Search functionality
    search_query = request.GET.get('search', '')
    if search_query:
        projects = projects.filter(name__icontains=search_query)
    context = {
        'projects': projects,
        'archived': archived,
        'search_query': search_query,
        'users': users,
    }
    return render(request, 'projects/project_list.html', context)

@login_required
def milestone_list(request, project_id):
    """List milestones for a specific project"""
    project = get_object_or_404(Project, id=project_id)
    milestones = project.milestones.all()
    users = get_user_model().objects.all()
    search_query = request.GET.get('search', '')
    if search_query:
        milestones = milestones.filter(name__icontains=search_query)
    context = {
        'project': project,
        'milestones': milestones,
        'search_query': search_query,
        'users': users,
    }
    return render(request, 'projects/milestone_list.html', context)

@login_required
def activity_list(request, project_id, milestone_id):
    """List activities for a specific milestone"""
    project = get_object_or_404(Project, id=project_id)
    milestone = get_object_or_404(Milestone, id=milestone_id, project=project)
    activities = milestone.activities.all()
    
    search_query = request.GET.get('search', '')
    if search_query:
        activities = activities.filter(name__icontains=search_query)
    
    context = {
        'project': project,
        'milestone': milestone,
        'activities': activities,
        'search_query': search_query,
    }
    return render(request, 'projects/activity_list.html', context)

@login_required
def activity_detail(request, project_id, milestone_id, activity_id):
    """Show activity details with comments"""
    project = get_object_or_404(Project, id=project_id)
    milestone = get_object_or_404(Milestone, id=milestone_id, project=project)
    activity = get_object_or_404(Activity, id=activity_id, milestone=milestone)
    
    context = {
        'project': project,
        'milestone': milestone,
        'activity': activity,
    }
    return render(request, 'projects/activity_detail.html', context)

@login_required
def backlog_filter(request):
    """Show all overdue items (backlog)"""
    activities = Activity.objects.filter(
        due_date__lt=timezone.now().date(),
        status=Status.OPEN
    ).select_related('milestone__project')
    
    milestones = Milestone.objects.filter(
        due_date__lt=timezone.now().date(),
        activities__status=Status.OPEN
    ).distinct().select_related('project')
    
    context = {
        'activities': activities,
        'milestones': milestones,
        'title': 'All Backlog',
    }
    return render(request, 'projects/filter_view.html', context)

@login_required
def next_4_weeks_filter(request):
    """Show items due in the next 4 weeks"""
    today = timezone.now().date()
    four_weeks_later = today + timedelta(weeks=4)
    
    activities = Activity.objects.filter(
        due_date__gte=today,
        due_date__lt=four_weeks_later,
        status=Status.OPEN
    ).select_related('milestone__project').order_by('due_date')
    
    context = {
        'activities': activities,
        'title': 'Next 4 Weeks',
        'today': today,
        'tomorrow': today + timedelta(days=1),
    }
    return render(request, 'projects/filter_view.html', context)

# Form handling views
@require_http_methods(["GET", "POST"])
@login_required
def add_project(request):
    """Add new project via modal form"""
    if request.method == 'POST':
        form = ProjectForm(request.POST)
        if form.is_valid():
            project = form.save()
            if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                return JsonResponse({
                    'status': 'success',
                    'message': 'Project created successfully',
                    'project_id': project.id,
                    'project_name': project.name
                })
            else:
                messages.success(request, 'Project created successfully')
                return redirect('projects:project_list')
        else:
            if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                return JsonResponse({
                    'status': 'error',
                    'errors': form.errors
                })
    else:
        form = ProjectForm()
    
    return render(request, 'projects/add_project_modal.html', {'form': form})


@login_required
@require_http_methods(["GET", "POST"])
def add_activity(request, project_id, milestone_id):
    """Add new activity with points via modal form"""
    project = get_object_or_404(Project, id=project_id)
    milestone = get_object_or_404(Milestone, id=milestone_id, project=project)
    
    if request.method == 'POST':
        form = ActivityForm(request.POST)
        if form.is_valid():
            activity = form.save(commit=False)
            activity.milestone = milestone
            activity.save()
            
            if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                return JsonResponse({
                    'status': 'success',
                    'message': 'Activity created successfully'
                })
            else:
                messages.success(request, 'Activity created successfully')
                return redirect('projects:activity_list', project_id=project.id, milestone_id=milestone.id)
        else:
            if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                return JsonResponse({
                    'status': 'error',
                    'errors': form.errors
                })
    else:
        form = ActivityForm()
    
    return render(request, 'projects/add_activity_modal.html', {
        'form': form,
        'project': project,
        'milestone': milestone
    })

# AJAX Views for dynamic updates
@login_required
def toggle_activity_status(request, activity_id):
    """Toggle activity status between open and closed"""
    if request.method == 'POST':
        activity = get_object_or_404(Activity, id=activity_id)
        activity.status = Status.CLOSED if activity.status == Status.OPEN else Status.OPEN
        activity.save()
        
        messages.success(request, f'Activity {"completed" if activity.status == Status.CLOSED else "reopened"}')
        return JsonResponse({
            'status': 'success', 
            'new_status': activity.status,
            'message': f'Activity {"completed" if activity.status == Status.CLOSED else "reopened"}'
        })
    
    return JsonResponse({'status': 'error'})

@login_required
def update_priority(request, model_type, object_id):
    """Update priority for project, milestone, or activity"""
    if request.method == 'POST':
        priority = request.POST.get('priority')
        
        if model_type == 'project':
            obj = get_object_or_404(Project, id=object_id)
        elif model_type == 'milestone':
            obj = get_object_or_404(Milestone, id=object_id)
        elif model_type == 'activity':
            obj = get_object_or_404(Activity, id=object_id)
        else:
            return JsonResponse({'status': 'error', 'message': 'Invalid model type'})
        
        old_priority = obj.priority
        obj.priority = priority
        obj.save()
        
        priority_labels = {
            'high': 'High Priority',
            'medium': 'Medium Priority',
            'low': 'Low Priority'
        }
        
        messages.success(request, f'Priority changed from {priority_labels.get(old_priority, old_priority)} to {priority_labels.get(priority, priority)}')
        return JsonResponse({
            'status': 'success',
            'message': f'Priority updated to {priority_labels.get(priority, priority)}'
        })
    
    return JsonResponse({'status': 'error'})

@login_required
def update_points(request, activity_id):
    """Update points for an activity (1 point = 30 minutes)"""
    if request.method == 'POST':
        activity = get_object_or_404(Activity, id=activity_id)
        points = int(request.POST.get('points', 0))
        
        old_points = activity.points
        activity.points = points
        activity.save()
        
        if points == 0:
            messages.success(request, 'Points removed from activity')
        else:
            messages.success(request, f'Points updated from {old_points} to {points}')
        
        return JsonResponse({
            'status': 'success',
            'formatted_points': activity.formatted_points,
            'message': f'Points updated to {points}' if points > 0 else 'Points removed'
        })
    
    return JsonResponse({'status': 'error'})

@login_required
def archive_project(request, project_id):
    """Archive a completed project"""
    if request.method == 'POST':
        project = get_object_or_404(Project, id=project_id)
        project.is_archived = True
        project.save()
        
        messages.success(request, f'Project "{project.name}" archived successfully')
        return JsonResponse({
            'status': 'success',
            'message': 'Project archived successfully'
        })
    
    return JsonResponse({'status': 'error'})

@login_required
def restore_project(request, project_id):
    """Restore an archived project"""
    if request.method == 'POST':
        project = get_object_or_404(Project, id=project_id, is_archived=True)
        project.is_archived = False
        project.save()
        
        messages.success(request, f'Project "{project.name}" restored successfully')
        return JsonResponse({
            'status': 'success',
            'message': 'Project restored successfully'
        })
    
    return JsonResponse({'status': 'error'})

@login_required
def add_comment(request, model_type, object_id):
    """Add comment to project, milestone, or activity"""
    if request.method == 'POST':
        comment_text = request.POST.get('comment', '').strip()
        
        if not comment_text:
            return JsonResponse({'status': 'error', 'message': 'Comment cannot be empty'})
        
        if model_type == 'project':
            obj = get_object_or_404(Project, id=object_id)
        elif model_type == 'milestone':
            obj = get_object_or_404(Milestone, id=object_id)
        elif model_type == 'activity':
            obj = get_object_or_404(Activity, id=object_id)
        else:
            return JsonResponse({'status': 'error', 'message': 'Invalid model type'})
        
        # Create comment using generic foreign key
        from django.contrib.contenttypes.models import ContentType
        content_type = ContentType.objects.get_for_model(obj)
        
        comment = Comment.objects.create(
            content_type=content_type,
            object_id=obj.id,
            text=comment_text
        )
        
        messages.success(request, 'Comment added successfully')
        return JsonResponse({
            'status': 'success',
            'message': 'Comment added successfully',
            'comment_html': f'<div class="comment-entry"><div>{comment.text}</div><div class="comment-date">{comment.created_at}</div></div>'
        })
    
    return JsonResponse({'status': 'error'})

def export_data(request):
    """Export all project data as JSON"""
    from django.http import HttpResponse
    import json
    from django.core import serializers
    
    # Serialize all related data
    projects = list(Project.objects.values())
    milestones = list(Milestone.objects.values())
    activities = list(Activity.objects.values())
    comments = list(Comment.objects.values())
    
    export_data = {
        'projects': projects,
        'milestones': milestones,
        'activities': activities,
        'comments': comments,
        'export_date': timezone.now().isoformat(),
        'version': '1.0'
    }
    
    response = HttpResponse(
        json.dumps(export_data, indent=2, default=str),
        content_type='application/json'
    )
    response['Content-Disposition'] = f'attachment; filename="projects-{timezone.now().date()}.json"'
    
    return response

def get_dashboard_stats(request):
    """API endpoint for dashboard statistics (AJAX)"""
    total_projects = Project.objects.count()
    active_projects = Project.objects.filter(is_archived=False).count()
    total_activities = Activity.objects.count()
    completed_activities = Activity.objects.filter(status=Status.CLOSED).count()
    overdue_activities = Activity.objects.filter(
        due_date__lt=timezone.now().date(),
        status=Status.OPEN
    ).count()
    
    total_points = Activity.objects.aggregate(Sum('points'))['points__sum'] or 0
    completed_points = Activity.objects.filter(status=Status.CLOSED).aggregate(Sum('points'))['points__sum'] or 0
    
    return JsonResponse({
        'total_projects': total_projects,
        'active_projects': active_projects,
        'total_activities': total_activities,
        'completed_activities': completed_activities,
        'overdue_activities': overdue_activities,
        'total_points': total_points,
        'completed_points': completed_points,
        'estimated_hours': total_points // 2,
        'completion_rate': round((completed_activities / max(total_activities, 1)) * 100),
    })
@require_http_methods(["GET", "POST"])
def add_project(request):
    """Add new project via modal form"""
    if request.method == 'POST':
        form = ProjectForm(request.POST)
        if form.is_valid():
            try:
                project = form.save()  # This actually saves to database
                
                if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                    return JsonResponse({
                        'status': 'success',
                        'message': 'Project created successfully',
                        'project_id': project.id,
                        'project_name': project.name
                    })
                else:
                    messages.success(request, 'Project created successfully')
                    return redirect('projects:project_list')
            except Exception as e:
                if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                    return JsonResponse({
                        'status': 'error',
                        'message': f'Error saving project: {str(e)}'
                    })
        else:
            if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                return JsonResponse({
                    'status': 'error',
                    'errors': form.errors
                })
    else:
        form = ProjectForm()
    
    return render(request, 'projects/add_project_modal.html', {'form': form})


def add_comment(request, model_type, object_id):
    """Add comment to project, milestone, or activity"""
    if request.method == 'POST':
        comment_text = request.POST.get('comment', '').strip()
        
        if not comment_text:
            return JsonResponse({'status': 'error', 'message': 'Comment cannot be empty'})
        
        try:
            # Get the correct model based on type
            if model_type == 'project':
                obj = get_object_or_404(Project, id=object_id)
            elif model_type == 'milestone':
                obj = get_object_or_404(Milestone, id=object_id)
            elif model_type == 'activity':
                obj = get_object_or_404(Activity, id=object_id)
            else:
                return JsonResponse({'status': 'error', 'message': 'Invalid model type'})
            
            # Create comment using generic foreign key
            content_type = ContentType.objects.get_for_model(obj)
            
            comment = Comment.objects.create(
                content_type=content_type,
                object_id=obj.id,
                text=comment_text
            )
            
            messages.success(request, 'Comment added successfully')
            return JsonResponse({
                'status': 'success',
                'message': 'Comment added successfully',
                'comment_html': f'''
                    <div class="comment-entry">
                        <div>{comment.text}</div>
                        <div class="comment-date">{comment.created_at.strftime("%b %d, %Y %I:%M %p")}</div>
                    </div>
                '''
            })
            
        except Exception as e:
            return JsonResponse({'status': 'error', 'message': f'Error adding comment: {str(e)}'})
    
    return JsonResponse({'status': 'error', 'message': 'Invalid request method'})

def milestone_list(request, project_id):
    """List milestones for a specific project"""
    project = get_object_or_404(Project, id=project_id)
    milestones = project.milestones.all()
    users = get_user_model().objects.all()
    search_query = request.GET.get('search', '')
    if search_query:
        milestones = milestones.filter(name__icontains=search_query)
    
    context = {
        'project': project,
        'milestones': milestones,
        'search_query': search_query,
        'users': users,
    }
    return render(request, 'projects/milestone_list.html', context)


# class ProjectForm(forms.ModelForm):
#     class Meta:
#         model = Project
#         fields = ['name', 'priority', 'due_date']
#         widgets = {
#             'name': forms.TextInput(attrs={
#                 'placeholder': 'Enter project name',
#                 'class': 'form-control',
#                 'required': True,
#                 'maxlength': '100'
#             }),
#             'priority': forms.Select(attrs={'class': 'form-control'}),
#             'due_date': forms.DateInput(attrs={
#                 'type': 'date',
#                 'class': 'form-control',
#                 'required': True
#             }),
#         }

#     def __init__(self, *args, **kwargs):
#         super().__init__(*args, **kwargs)
#         from django.utils import timezone
#         self.fields['due_date'].widget.attrs['min'] = timezone.now().date().strftime('%Y-%m-%d')

# class MilestoneForm(forms.ModelForm):
#     class Meta:
#         model = Milestone
#         fields = ['name', 'priority', 'due_date']
#         widgets = {
#             'name': forms.TextInput(attrs={
#                 'placeholder': 'Enter milestone name',
#                 'class': 'form-control',
#                 'required': True,
#                 'maxlength': '100'
#             }),
#             'priority': forms.Select(attrs={'class': 'form-control'}),
#             'due_date': forms.DateInput(attrs={
#                 'type': 'date',
#                 'class': 'form-control',
#                 'required': True
#             }),
#         }

#     def __init__(self, *args, **kwargs):
#         super().__init__(*args, **kwargs)
#         from django.utils import timezone
#         self.fields['due_date'].widget.attrs['min'] = timezone.now().date().strftime('%Y-%m-%d')

# class ActivityForm(forms.ModelForm):
#     class Meta:
#         model = Activity
#         fields = ['name', 'priority', 'due_date', 'points'
#         widgets = {
#             'name': forms.TextInput(attrs={
#                 'placeholder': 'Enter activity name',
#                 'class': 'form-control',
#                 'required': True,
#                 'maxlength': '100'
#             }),
#             'priority': forms.Select(attrs={'class': 'form-control'}),
#             'due_date': forms.DateInput(attrs={
#                 'type': 'date',
#                 'class': 'form-control',
#                 'required': True
#             }),
#             'points': forms.NumberInput(attrs={
#                 'class': 'form-control',
#                 'min': '0',
#                 'max': '100',
#                 'placeholder': 'e.g., 4 points = 2 hours'
#             }),
#         }

#     def __init__(self, *args, **kwargs):
#         super().__init__(*args, **kwargs)
#         from django.utils import timezone
#         self.fields['due_date'].widget.attrs['min'] = timezone.now().date().strftime('%Y-%m-%d')