from django.contrib.auth import get_user_model
from django.views.decorators.http import require_POST
from django.http import JsonResponse
from django.contrib.auth.decorators import login_required
from .models import Project

@require_POST
@login_required
def assign_project_user(request, project_id):
    import logging
    logger = logging.getLogger(__name__)
    user_id = request.POST.get('user_id')
    logger.debug(f"Assigning user: user_id={user_id}, project_id={project_id}")
    try:
        if not user_id:
            logger.error("No user_id provided in POST data.")
            return JsonResponse({'status': 'error', 'message': 'No user_id provided.'})
        try:
            user = get_user_model().objects.get(pk=user_id)
        except Exception as e:
            logger.error(f"User not found: {e}")
            return JsonResponse({'status': 'error', 'message': f'User not found: {e}'})
        try:
            project = Project.objects.get(pk=project_id)
        except Exception as e:
            logger.error(f"Project not found: {e}")
            return JsonResponse({'status': 'error', 'message': f'Project not found: {e}'})
        project.assigned_to = user
        project.save()
        logger.info(f"Assigned user {user} to project {project}")
        return JsonResponse({'status': 'success', 'assigned_to': user.get_full_name() or user.username})
    except Exception as e:
        logger.error(f"Unexpected error: {e}")
        return JsonResponse({'status': 'error', 'message': f'Unexpected error: {e}'})
