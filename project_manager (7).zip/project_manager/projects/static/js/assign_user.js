// AJAX for assigning user to project
function assignUserToProject(projectId, userId, selectElem) {
    fetch(`/api/project/${projectId}/assign-user/`, {
        method: 'POST',
        headers: {
            'X-Requested-With': 'XMLHttpRequest',
            'X-CSRFToken': getCSRFToken(),
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        credentials: 'same-origin',
        body: `user_id=${encodeURIComponent(userId)}`
    })
    .then(response => response.json())
    .then(data => {
        if (data.status === 'success') {
            showToast('User assigned successfully!', 'success', 5000);
            // Update the label for 'Assigned to' in the UI
            let assignedName = data.assigned_to || selectElem?.options[selectElem.selectedIndex]?.text || 'Unassigned';
            if (selectElem) {
                // Try to find the label in the same <p> as the select
                let parentP = selectElem.closest('p');
                if (parentP) {
                    // Remove any text nodes after the select and append the new label
                    let labelSpan = parentP.querySelector('.assigned-label');
                    if (!labelSpan) {
                        labelSpan = document.createElement('span');
                        labelSpan.className = 'assigned-label';
                        parentP.appendChild(labelSpan);
                    }
                    labelSpan.textContent = ` → ${assignedName}`;
                }
            }
        } else {
            showToast(data.message || 'Failed to assign user', 'error', 4000);
        }
    })
    .catch(() => {
        showToast('An error occurred while assigning user', 'error', 4000);
    });
}
window.assignUserToProject = assignUserToProject;
